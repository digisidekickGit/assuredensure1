const GCV3 =[
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Chassis (Xp) (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Chassis (Xp) (6250 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range Ti Dlv 3350 Wb Rhd E-ii Vcehicle (Di) (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range Ti Dlv 3350 Wb Rhd E-ii Vcehicle (Di) (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1-strong 3100 Wb Bs Ii Vehicle (Hsd) (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1-strong 3100 Wb Bs Ii Vehicle (Hsd) (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1-strong 3100 Wb Bs Iii Vehicle (Hsd) (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1-strong 3100 Wb Bs Iii Vehicle (Hsd) (5850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Zoom (Cab\/pto) (5950 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1 Dv 3050 Wb Vehicle Complete (Euro Iii (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Range T1 Dv 3050 Wb Vehicle Complete (Euro Iii (3510 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls (3320mm Wb) (6860 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Half Body (Fsd \/ Dsd) Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Half Body (Fsd \/ Dsd) Xp (6250 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc-shd Prestige 4260mm (14) High Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Lwb Shd Prestige 5240mm (17) High Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc-shd Prestige 4260mm (14) High Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Lwb Shd Prestige 5240mm (17) High Deck (6440 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Half Body (F S D \/ D S D) (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And Half Body (F S D \/ D S D) (6250 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Cng (7490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Half Body ( Drop Side Deck) (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Half Body ( Drop Side Deck) (5400 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49es Tc Shd Premium 3740mm (12.25) High Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49es Tc Shd Premium 3740mm (12.25) High Deck (6200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Half Body (Fixed Side Deck ) (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Half Body (Fixed Side Deck ) (5400 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Lwb Prestige 5240mm (17) Fix Side Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Elwb Prestige 6610mm (21) Fix Side Desk (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc A Prestige 3100mm (10) Fix Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bl Al Box Prestige 5240mm (17) Aluminium Box (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc A Prestige 3100mm (10) Fix Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Prestige 4260mm (14) Fix Side Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Elwb Prestige 6610mm (21) Fix Side Desk (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Prestige 4260mm (14) Fix Side Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bl Al Box Prestige 5240mm (17) Aluminium Box (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A Lwb Prestige 5240mm (17) Fix Side Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc A (Ds) Premium 3740mm (12.25)drop Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc A (Ds) Premium 3740mm (12.25)drop Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26stc (Ds)sartaj 3740mm (12.25) Drop Side Deck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26stc (Ds)sartaj 3740mm (12.25') Drop Side Deck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A (Ds) Prestige 4260mm (14) Drop Side Desk (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc A (Ds) Prestige 4260mm (14) Drop Side Desk (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc A (Ds) Prestige 3100mm (10) Drop Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc A (Ds) Prestige 3100mm (10) Drop Side Deck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Alhd Prestige 4260mm (14) Aluminium High Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Alhd Prestige 4260mm (14) Aluminium High Deck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Al C.body Prestige 4260mm (14) Aluminium Cargo Body (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Al C.body Prestige 4260mm (14) Aluminium Cargo Body (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-a Cosmo 3100mm (10) Fix Side Deck (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-a Cosmo 3100mm (10) Fix Side Deck (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Adc Prestige 3100mm (10) Fix Side Deck With Dual Cabin (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Adc Prestige 3100mm (10) Fix Side Deck With Dual Cabin (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc Sartaj 3740mm (12.25') Semi High Deck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc Sartaj 3740mm (12.25) Semi High Deck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc Sartaj Euro Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc Sartaj Euro Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-b Cosmo Cabin And Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-b Cosmo Cabin And Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis. (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis Gvw 5990 (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj (Wb - 3335) Wv26s Tc B Sartaj Cabin And Chassis Gvw 5990 (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-b - Pto Cosmo Cabin And Chassis With Pto (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo (Wb - 2815) Wv26tc-b - Pto Cosmo Cabin And Chassis With Pto (5740 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Cabking Delivery Van (3700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Cabking Cabking 576 Truck (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Cabking Cabking 576 Truck (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Cng Refrigerated Van (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Jayo Cbc Ps (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Jayo Cabin & Load Dsd Ps (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Jayo Hsd Bsiv (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Jayo (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Jayo. (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Di 3200 Refrigerated Van (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Load King 6t Cbc Bs3 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Load King 6t Cbc Bs3 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd Bs2 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd Bs2 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bsii Fsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bsii Hsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bsii Hsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Lwb Cabin And Load Carrier Bs3 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Fsd Bs3 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Lwb Cabin And Load Carrier Bsii (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd. (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Pride Lwb Cab And Load Carrier (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd. (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Super Lwb Cab And Chassis Bs2 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd Bs3 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Fsd Bs2 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Fsd Bs2 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bs3 Fsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Lwb Cabin And Load Carrier Bsii (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Lwb Cabin And Load Carrier Bs3 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bs3 Hsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Super 6t Cabin And Chassis Bs2 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bs3 Hsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bs3 Fsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Super 6t Cabin And Chassis Bs2 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Fsd Bs3 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Jetking (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 6t Cabin And Load Carrier Bsii Fsd (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking 4t Swb (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Lwb Cabin And Load Carrier Hsd Bsiv (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Pride Lwb Cab And Load Carrier (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Super Lwb Cab And Chassis Bs2 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Jetking (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking Loadking Pride 4t Cabin And Load Carrier Hsd Bs3 (5500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Loadking 6t Cbc Refrigerator Van (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di-3200 Cabin And Load Carrier Bs Ii (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di 3200 (6250 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di-3200 Cab And Chassis Bsii (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di-3200 Cabin And Load Carrier Bs Ii (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di 3200 (6250 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di 3200 Gvw 4600 (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Di-3200 Cab And Chassis Bsii (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Pride 6t (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Super (5940 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Optima Cbc Swb Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Sherpa (7450 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Optimo Cbc Hd (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking Fbt Bsiv Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Loadking 3.3 6t (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tipper Di 3200 Tippers (6250 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking Optima 6t Swb Hsd (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 3.3l 6t Cbc Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Di 3200 Cabin And Load Carrier Hsd Gvw 4850 (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Di 3200 Jayo Hsd Cng (4850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking Pride 6t Cng Bsiv Cbc (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Di 3200 Jayo Gvw 4600 (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Di 3200 Cabin And Load Carrier Hsd (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 3.3l 6t Swb Cab & Load Carrier (6950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking Optima 4t Lwb Cng (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking Zoom 4t Lwb Hsd. (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 6t Cbc Gvw 5700 (5700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 4t Lwb Hsd Cng. (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 6 Tyre Lwb (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 3.3l 6t Cbc Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Optimo Cbc Hd (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking 4t Lwb Cng Bsiv Container (5950 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Di 3200 (4600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Trucks Loadking Zoom 4t Lwb Hsd Cng (6255 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Water Tanker Loadking Super Di (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Dumper Sfc 709 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lp\/709\/38\/cowl Ex\/ Eii Lp\/709\/38\/cowl Ex\/ Eii (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lp\/709\/38\/cowl Ex\/ Eii Lp\/709\/38\/cowl Ex\/ Eii (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 407 Cng Ex2 Refrigerator Van (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 407 Ex Refrigerator Van Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 407\/34 Turbo-ex Refrigerator Van (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 407\/38 Ex2 Refrigerator Container (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 407\/38 Ex2 Refrigerator Van (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt 709 Ex2 Refrigerator Van (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/cab\/ex\/e Ii Lpt\/407\/34\/cab\/ex\/e Ii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/cab\/ex\/e Ii Lpt\/407\/34\/cab\/ex\/e Ii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/clb\/ex\/eii Lpt\/407\/34\/clb\/ex\/eii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/clb\/ex\/eii Lpt\/407\/34\/clb\/ex\/eii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/hd\/ex\/eii Lpt\/407\/34\/hd\/ex\/eii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/407\/34\/hd\/ex\/eii Lpt\/407\/34\/hd\/ex\/eii (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/cab\/ex\/eii Lpt\/709\/34\/cab\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/cab\/ex\/eii Lpt\/709\/34\/cab\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/clb\/ex\/eii Lpt\/709\/34\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/clb\/ex\/eii Lpt\/709\/34\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/hd\/ex\/eii Lpt\/709\/34\/hd\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/34\/hd\/ex\/eii Lpt\/709\/34\/hd\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/cab\/ex\/eii Lpt\/709\/38\/cab\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/cab\/ex\/eii Lpt\/709\/38\/cab\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/clb\/ex\/eii Lpt\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/clb\/ex\/eii Lpt\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/clb\/ex2\/ps\/eii Lpt\/709\/38\/clb\/ex2\/ps\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Lpt\/709\/38\/clb\/ex2\/ps\/eii Lpt\/709\/38\/clb\/ex2\/ps\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker Sfc 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker Sfc 709 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker 709 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Null 407 Pick Up (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Sfc 407 Pick Up (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Sfc 407 Pick Up. (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Ex\/31 Ht (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Refrigerator Van Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Refrigerator Van (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/cab\/ex\/eii Sfc\/407\/31\/cab\/ex\/eii (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/cab\/ex\/eii Sfc\/407\/31\/cab\/ex\/eii (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/clb\/ex\/eii Sfc\/407\/31\/clb\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/clb\/ex\/eii Sfc\/407\/31\/clb\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex\/eii Sfc\/407\/31\/hd\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex\/eii Sfc\/407\/31\/hd\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex2\/ps\/eii Sfc\/407\/31\/hd\/ex2\/ps\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex2\/ps\/eii Sfc\/407\/31\/hd\/ex2\/ps\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/cab\/ex\/eii Sfc\/709\/38\/cab\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/cab\/ex\/eii Sfc\/709\/38\/cab\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/clb\/ex\/eii Sfc\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/clb\/ex\/eii Sfc\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/hd\/ex\/eii Sfc\/709\/38\/hd\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/hd\/ex\/eii Sfc\/709\/38\/hd\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 709 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 709 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 3800 (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Gvw 7490. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 713 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ht Clb (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5600 (5600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5700 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Exii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 410 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407\/29 Bsiv Pickup Clb (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 410 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5700 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Hd (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 609 (6700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cab. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cng Dsd (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5550 (5550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Cab Cng (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Tt Clb (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hsd. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab Cng (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Exii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hdlb Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 712 Ex. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hsd (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 410 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407. (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 13.7 Ft Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 810 Ex\/38 Crx Bsiv Hdlb (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 712 Ex. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Hdlb Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/34 Ex2 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Clb Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Tata 712 Truck (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Tt Clb. (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 410 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Cng Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cab (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Tata 712 Truck (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex Cab (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407. (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex Bs Iv Hdlb. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Hdlb (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5950. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 613 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 713 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab Cng. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex Cab Cng (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 5600. (5600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Cab Cng. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Hsd (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407\/31 Ex Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Tt Cab (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Hdlb (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 Bsiv Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 Clb (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 609 (6700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 712 Ex Cab And High Deck. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Ex2 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 613 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex Hsd (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Ex (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Tipper (5800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Sk 407 Ex (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Bsiv (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Sk 407 (6250 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Ecomet 912 (7500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Ecomet 912 (7500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Milk Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner Le (4720 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner 14ft Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner 4 Tyre 14ft Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Gvw 6700 (6700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hdlb Bsiv Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Gvw 6600 (6600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Mls Fsd 14 Ft Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 4 Tyre Hsd 3320mm Ls Bsiv (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 4 Tyre Hsd 2670mm Bsiv Ps (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6020 (6020 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hsd 3320mm Bsiv Gvw 6860 (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Cargo 709 (7350 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6700 (6700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Fsd 11ft 6 Tyre (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls 14 Ft Hsd Gvw 6860 (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 6 Tyre 3955mm Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Mls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6600 (6600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 6 Tyre Xls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6700. (6700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10 59 Refrigerated Van (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Chassis (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Chassis (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab With Aluminum Container Body With Wind Deflector (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab With Aluminum Container Body With Wind Deflector (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Xp Hsd Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E 134 Cab And Chassis (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Rhd Cab And Chasis (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd. (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Xp Hsd Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Rhd Cab And Chasis (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E 134 Cab And Chassis (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab With Aluminum Container Body (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab With Aluminum Container Body (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 Xp Cng Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng Gb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng Gb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750. (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Dumper Placer Dumper Placer (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.59 Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.59 Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.75 Refrigerated Van (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.75 Refrigerated Van (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher Truck Pro 1075 F Hsd Bs3 Ngb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Fuel Carrying Tanker Pro 1059 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Garbage Tipper Garbage Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Milk Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Null Eicher 10.59 Tipper (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Null Eicher 10.75 Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 10.59 C Hsd Bs3 Ngb (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1049 C Refrigerated Van (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1055 Refrigerator Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1059 Xp Refrigerated Van (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Rear Drop Tipper Rear Drop Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck Pro 1075 F Cbc Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck 10.50 E (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck 10.50 E (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck Pro 1059 Xp F Hsd Ngb Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59. (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1080 Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E. (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Gvw 7200. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Cbc Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 C Hsd (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Ngb 16ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 C (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 C Fsd Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Fsd. (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.70 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1050 E Cbc. (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 E Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C Fsd Bsiv (5490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd Bs Iv (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Cbc Cng Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 11.10 Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Cng Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cbc Bsiv Cng (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 E Cbc Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Cbc (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 C Dsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp Hsd. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp E Hsd Gvw 7400 (7400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd 14 Ft (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd Cab And Chasis (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd Cab And Chasis (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 10.59 Xp E Hsd Ngb 14ft (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cab And Chassis. (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng 14 Ft Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 K Cbc (5490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59. (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1050 E Hsd (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd Cng (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Gvw 7500 (7500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.50 (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd 16ft Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xpl (7250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 6037 C Hsd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Hsd Cng Ngb 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp Hsd (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cab And Chassis (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Ngb 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Hsd Cng Ngb 14ft. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Fsd (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 10.59 Xp E Hsd 14ft (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng 12 Ft Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C. (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 11.10 Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.70 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 C Fsd (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 H Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.50 (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Cbc 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 H Hsd Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xpl (7250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Cbc Cng Ngb 14ft. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Water Tanker (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Water Tanker Water Tanker (7450 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Matador F 307 (3510 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Matador F 307. (3510 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Excel 4 (5850 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Excel 4. (5850 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Traveller Delivery Van (3510 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wt49es Tc Al C.body Premium Aluminium Cargo Body (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26stc Al Box Sartaj Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26tc Al Box Cosmo Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26stc Al Box Sartaj Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wt49es Tc Al C.body Premium Aluminium Cargo Body (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26tc Al Box Cosmo Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Fes Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Prestige Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Fes Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Zt50tclwb Fes Prestige Drive Away Chassis With Foh (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Fes Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Fes Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Cosmo Cowl Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Zt50tclwb Fes Prestige Drive Away Chassis With Foh (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Prestige Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Sartaj Cowl Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Sartaj Cowl Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Fes Prestige Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Fes Prestige Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Cosmo Cowl Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo Wv26tc-b Cosmo (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo Wv26tc-b Cosmo (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49es Tc B Dumpr Plc Premium Dumper Placer (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49tc Dp Prestige Dumper Truck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49es Tc Dp Premium Dumper Truck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt48tc Dp Prestige Dumper Truck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Delevery Van Wv26tc-b Del. Van Cosmo Delivery Van (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Delevery Van Wv26tc-b Del. Van Cosmo Delivery Van (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tca Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tclwb Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26stcd Fes Fl Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26stcd Fes Fl Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tca Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26tcd Fes Fl Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tclwb Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26tcd Fes Fl Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu Truck Wv26s Tc-iii Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu Truck Wv26s Tc-iii Shd. (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49estc B Pto Premium Cabin And Chassis With (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49estc B Pto Premium Cabin And Chassis With (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Milk Tanker Swaraj 4wd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Elwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Pto Prestige Cabin And Chassis With Pto (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Fes Premium Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc B Premium Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Premium Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Premium Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Fes Premium Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Pto Prestige Cabin And Chassis With Pto (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Prestige Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Lwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Lwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Elwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bdc Prestige Dual Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Prestige Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc B Premium Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bdc Prestige Dual Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Truck (6390 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Truck (6390 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Hg72 Wv26s-tc Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26stc A (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26sm Ng Cbc Cng. (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26s Ng (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26sm Gh Ng Smdc (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26 S (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26s Iv Gh Ng Smdc. (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26sm Ng 72 Smdc Cng (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26s Ng 14 Ft 3335mm Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Wv26sm Ng72 Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Xm 14 Feet (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt50tc A D.van Prestige Delivery Van (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt48tc-d Del.van Prestige Delivery Van (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt48tc-d Del.van Prestige Delivery Van (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt50tc A D.van Prestige Delivery Van (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Metro Zt54 Ng Shd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Metro Zt54 Ng Shd. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Truck Super (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Truck Super (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Swaraj Truck T 3500 (6990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Swaraj Truck T 3500 (6990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Tipper Wt 49 Estc (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Prestige 2815 Steel High Deck Bs Iv Ps (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Shd Bs Iv Ps. (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs Bsiv 3335mm Cng Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Supreme 4240 Steel High Deck Lwb Bs Iv (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Cab (4990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs Bsiv 3335mm Cng Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng A Elwb. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Hsd (5200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng A Elwb (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Xm Shd Bs Iv (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs 14ft Bsiv 3335mm Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Wv26s Tc Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng Iv Gh Shd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 59 Xm Cargo Box Bsiv (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Cab Gvw 5200 (5200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Shd (5220 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 59 Xm High Deck (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Wv26s Ng Shd 14 Ft Cng Gvw 5990 (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Prestige Xm 14ft 4x2 3335mm (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Tc Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Xm Shd Bs Iv. (7200 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Excel 4 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Excel 4 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Tanker Excel (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Tanker Excel (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Tidv 3350 Wb Bsiv Ps (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Fm 2.6 Cr 4020wb Dv Gvw 4150 (4150 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Delivery Van (3900 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Traveller Strong (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van Smart (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T2 4020 Wb Delivery Van (5550 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Shaktiman Td 2650 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van Cng (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Utility Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Td 2650 Delivery Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van 3700 Wb Abs Ps (3810 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Td 3050 Wb Bs4 Fm2.6cr Ps Rfr (3650 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Strong (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Traveller Strong (5850 GVW)"
 }
]

module.exports = {
    GCV3
  };