const GCV2 = [
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus (Ps) (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Refrigerated Van Maxi Truck Plus Mdi (Ps) (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus (Ps). (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Di Bp\/nbp ( 13.6x28) (2520 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Roadstar Roadstar Sa (Leaf-spring) E-ii (2500 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "215 Di (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "215 Di Yuvraj (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "215 Yuvraj (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "225 Di Tractor (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "235 Airflow (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "235 Di (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "235 Di Bp (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "235bp (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "245 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "245 Di Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "255 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "255 Di Yuvraj (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "255 Yuv (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Bhoomiputra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Nbp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Obp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Power Plus (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Di Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Mkm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Nbp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Bic (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Di Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Di Nbp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Di Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Ns (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "275 Sp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Nst Turbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Sarpanch Dlx (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Sarpanch Turbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Super Turbo Deluxe (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "295 Di Turbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "365 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "415 Bp Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "415 Di Nbp Dlx Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "415 Nst Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "445 Arjun (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "445 Arjun Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "445 Di Arjun Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "445 Di Ps Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Bic (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Bhoomiputra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Bpe (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Nbp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Nst Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Nstwl-oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Obp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Di Sarpanch Mkm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Mkm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "475 Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Arjun (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Arjun Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Di Arjun Dlx (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Di Arjun Ps Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Di Arjun Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "555 Di Ps Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Bic (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Bp Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Base (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Bhoomiputra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Bic Crpto (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Bpe (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Mkm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Mkm Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Mkm Oib Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Mkm Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Nbp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Nst Rotry Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Nstwl-oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Di Sarpanch Oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Obp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "575 Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "585 Bic (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "585 Dc Ps (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "585 Di Power Plus (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "585 Di Sarpanch (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "585 Eco (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Oib Turbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Sar (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Sarpanch Turbo Dlx (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Di Tarbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Tc (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "595 Turbo (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Arjun (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Arjun Ce (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Arjun Crpto (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Arjun Rjc (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Di Arjun Cg (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Di Arjun Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Di Ce Ultra (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "605 Di Ultra Hd (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "757 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "8275 Di (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 443 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 445 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 555 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 605 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 605 Dlx (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Arjun 7575 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "B 275 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus 1.2t Bsiv (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pik Up (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up El Cbc 1.7t Gvw 3425 (3425 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb Cbc 1.5t Ps Gvw 3220 (3220 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up 2wd (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Big Pick Up Fb 1.7t Ps (3425 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb Ps (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up 4wd (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 2wd. (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pik Up Cng (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.5t Ps (3225 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Bs Iv (2670 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up 4wd Gvw 2750 (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Di Turbo (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Gvw 2820 (2820 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus 1.2t Bs Iv Ps. (2670 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Cng (2745 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Cbc 1.5t Ps. (3225 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus 2wd Mdi Gvw 2670 (2670 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Sc Xl 2wd Cng Gvw 2880 (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Big Pick Up 1.25t Ps (2975 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Std Bs Iii (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Cng Gvw 2620 (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.3t Ms Es Gvw 2990 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Ps Gvw 2880 (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Cbc 1.5t Ps (3225 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Sc 4wd (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus 1.2t Bs Iv Ps (2670 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Es Fb 1.29t Ps (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 2wd Bsiii (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb Cng (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.5t Ps Gvw 3225 (3225 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Gvw 2620 (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.25t Ps Gvw 2975 (2975 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.5t Ps Bsiv Gvw 3220 (3220 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Fb 1.7t Ps (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus 2wd Mdi (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck Plus Cng. (2745 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Cbc (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pick Up Cbc. (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Maxi Truck 2wd (2745 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Pik Up. (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Gold Vx 2wd (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Gold Vx Gvw 2510 (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Gold Vx Gvw 2510. (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Di Long 4wd Cmvr (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl 2wd (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Ps 4wd Bsiv (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Bolero Camper (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper 2wd Ps (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl Cng (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl 2wd. (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl Flat Bed 2wd (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Dlx A\/c 2wd (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Gold Life Style 2wd (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl 2wd Tc (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper 2wd (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Sc Xl 2wd Cng (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Gold (2510 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Huber Ps (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Dlx 2wd Cmvr (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper Di Long 2wd Cmvr (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Camper 2wd. (2880 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Refrigerated Van Pick Up Ps (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Refrigerated Van Maxi Truck Plus Cng (2620 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Bolero Refrigerated Van Pick Up Cbc (2960 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Double Cab Double Cab (3150 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 312 1s (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 312 Sa (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 453 Dlx (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 453 Regular (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 614 1a (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 804 1e (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "G 804 5e (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Genio (2930 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Genio Sc. (2930 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Genio Dc Vx (2930 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Genio Sc (2930 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Hindustan G 804 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Hwd 50 1a (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Hwd 50 2a (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Hwd 50 5a (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Dc Bs4 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Sc Bs3 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Dc Bs3 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Sc Vx Bs3 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Dc Vx Bs4 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Dc Vx Bs3 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Dc Vx. (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Sc Vx Bs4 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Imperio Sc Bs4 (2990 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "M 245 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra 475 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Maxx Pick-up 2wd Bs3 (2820 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Maxx Pick Up Cbc Fb 2wd (2820 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Single Cab 4wd Inline Pump Cmvr (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Single Cab 2wd Inline Pump (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Yuvraj (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra-575 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxx Maxi Pick Up. (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxx Maxi Truck Cng (2820 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxx Maxi Truck (2820 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg 312 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg 353 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg 405 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg 405 E (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg 453 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mg S35 Tractor (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mm 900 Mm 900 4wd (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mm 900 Mm 900 Md 2wd (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mm 950 Single Cab Mdi Tc (2750 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "S 30 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "S 35 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "S 453 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Scorpio Getaway (2650 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Shaan (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Shaktiman (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Shaktiman 535 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Shaktiman 55 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Single Cab Sc 2wd (3150 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Single Cab Sc 4wd (3150 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 724 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 724 Xm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 735 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 735 Fe (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 735 Xm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 744 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 744 Fe (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 834 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 843 Xm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Swaraj 855 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tr605 Di Ce Ult-oib (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Di New Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor Shaan (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor Arjun Ultra 555 Base Model (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 245 Di 2pc Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 595 Di Sar (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 275 Nst Cm (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 235 Di Air Flow (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Nst-large Tyre (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Di Bp-e (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 575 Di New Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 295 Di Turbo - 12.4x28 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor Arjun Ultra 605 Base Model (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 275 Di New Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Di Bp-e (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor Arjun Ultra 605 Di Ce (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 265 Di New Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 265nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 575 Di Nst With Rotary Fip (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 575 Di Bp -- E* (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 275 Di Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 475 Nst (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 265 Di Bp (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 255 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Tractor 295 Di Turbo - 13.6x28 (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Ultra 555 Di (2520 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Utility Utility Pick Up Van (2523 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Yuvo 265 Di (2520 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Crew Cab 207 Di Crew Cab (2820 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Ex Ps (2956 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Ex Ps Bs Ii 207 Di Ex Ps Bs Ii (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Rx Bs Iv (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Rx Bsiv Ps (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Rx Ps 207 Di Rx Ps (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "207 Di Rx Refrigerated Van (2956 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Null Winger Cargo (2850 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sumo Dl (2540 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 207 Di (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 207 Di (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata 207 Rx Pickup Clb (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata 207 Ex Pickup (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata 207di\/31na Kamani Rx \/ Ms Tata 207di\/31na Kamani Rx \/ Ms (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Mobile 4x4 Cab Crew (2780 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Telco Line Tl Double Cab 4*4 (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Telco Line Tl Single Cab 4*4 (2950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Telco Line Tl Double Cab 4*2 (2950 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Strong Ls Fsd Gvw 2545 (2545 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Lx. (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls Cng Gvw 2545 (2545 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Lite Bsiv Rfs Ls (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Ls (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le. (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls. (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le (2525 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le Cng Bs Iii (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Fsd Bsiv (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le Ruv (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Rfs Le Rs Bsiv Hsd (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Lx (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le Hd (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Rfs Cng 2350 Mm (2545 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Rls Fsd Bsiv. (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Lx Ruv (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Rls Bs Iv (2525 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Rfs Le Cbc Cng Gvw 2545 (2545 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Le Bs Iv (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Ls Fsd Bsiv (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls Cng (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Ls Ps (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Rls Bs Iv Gvw 2950 (2950 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Strong Ls Cbc Gvw 2545 (2545 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Plus Rls Fsd Bsiv (2750 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls Ruv (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Ls Cng. (2500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Dost Strong Lx 2.85t (2850 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Trax Tempo Trax (2750 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Trax Delivery Van (2800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Traveller Delivery Van (3490 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Roadstar Roadstar E-ii (2500 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu D Max Space Cab Arched Deck (2850 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu D Max Space Cab Flat Deck (2850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan 300 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan 400 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan 400 Hbt (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan 450 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan 500 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Balwan Di 330 Tractor (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Kargo King Kargo King (2750 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Ox 25 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Ox 25 Orchard (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Ox 45 (2520 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Tempo Trax Kargo Tempo Trax Kargo (2850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van Smart. (3490 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Trax Kargo King (2850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Trax Pick Up Trax Pick Up (2750 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Truck Shaktiman 200 Hsd Gvw 3475 (3475 GVW)"
 },
 {
  "Company": "International",
  "Variant": "60 Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "725 Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "730 Di Ii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "740 Super (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "745 Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "745 Iii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "750 Iii Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Baagban Di 30 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 35 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 35 Ii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 35 Ii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 39 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 39 Rx Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 42 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 45 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 52 Rx Dc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 52 Rx Dc Oib Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Hp Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Iii Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Iii Dc Oib Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Iii Dc Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Mm (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Mm Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Ps Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Rx Dc Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 60 Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 734 Iii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 734 Tractor (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 740 Iii Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 740 Iii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 740 Iii Sc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Iii Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Iii Dc Oib Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Iii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Iii Sc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Iii Sc Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 745 Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 75 Dc Ps Turbo (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 75 Dc Turbo Special (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 75 Tractor (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Ii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Ii Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Ii Dc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Dc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Dc Oib Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Sc Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Iii Sc Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Ps Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 750 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di 755 Dc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di Rx 750 Iii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Di-60 Dc Ps (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "International B 275 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Rx 42 Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Rx 42 Ps Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Rx 47 Ps Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Rx 50 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Rx 60 Iii Ps Oib (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 35 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 40 Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 42 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 735 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 740 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 740 Iii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika 745 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 30 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 340 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 35 Sc (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 450 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 47 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 55 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 60 Dc World Trac (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 60 Rx (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 60 Senior (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 730 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 730 Iii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 732 Iii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 740 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 745 Iii (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 750 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 755 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Di 760 (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "Sonalika Standard 335 Di (2520 GVW)"
 },
 {
  "Company": "International",
  "Variant": "World Track 75 (2520 GVW)"
 }
]

module.exports = {
    GCV2
  };