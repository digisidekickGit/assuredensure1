const router = require("express").Router();
const { getAccountancy, getAccountancyCheckAllModal } = require("../../controller/AccountancyController");

router.get("/", getAccountancy);
router.get("/getAccountancyCheckAllModal", getAccountancyCheckAllModal);


module.exports = router;
