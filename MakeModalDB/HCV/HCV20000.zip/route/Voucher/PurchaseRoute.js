const router = require("express").Router();

const {
  getPurchase,
  postPurchase,
  putPurchase,
  deletePurchase,
  getIsPurchase,
  getSingle,
  getGenerateReport,
} = require("../../controller/PurchaseController");

router.get("/", getPurchase);
router.get("/single/:id", getSingle);
router.get("/getGenerateReport/:id", getGenerateReport);
router.post("/getIsPurchase", getIsPurchase);
router.post("/", postPurchase);
router.put("/:id", putPurchase);
router.delete("/:id", deletePurchase);

module.exports = router;
