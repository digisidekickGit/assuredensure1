const router = require("express").Router();
const {
  getInsuranceCompany,
  postInsuranceCompany,
  putInsuranceCompany,
  deleteInsuranceCompany,
} = require("../../controller/InsuranceCompanyController");
const { protectRequests } = require("../../middleware/protectRequests");

router.get("/", getInsuranceCompany);
router.post("/", protectRequests,postInsuranceCompany);
router.put("/:id",protectRequests, putInsuranceCompany);
router.delete("/:id", protectRequests,deleteInsuranceCompany);
module.exports = router;
