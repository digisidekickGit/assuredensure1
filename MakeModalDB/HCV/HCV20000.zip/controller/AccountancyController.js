const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const getAccountancy = async (req, res, next) => {
  // Ledger=${Pos}&StartDate=${StartDate}&EndDate=${EndDate}&lookFor=${true}
  try {
    const { Ledger, lookFor, EndDate, StartDate } = req.query;
    const data = await AccountancySchema.aggregate([
      {
        $match: {
          Ledger: ObjectId(Ledger),
          EntryDate: {
            $gte: StartDate,
            $lte: EndDate,
          },
        },
      },
      {
        $lookup: {
          from: lookFor,
          localField: "oppositeLedger",
          foreignField: "_id",
          as: "oppositeLedger",
        },
      },
      {
        $unwind: "$oppositeLedger", // marge multiple docs in one array of objects
      },
      {
        $project: {
          _id: 1,
          VoucherType: 1,
          EntryDate: 1,
          RefNumber: 1,
          Ledger: 1,
          DR: 1,
          CR: 1,
          Amount: 1,
          CreatedWhich: 1,
          oppositeLedger: {
            _id: 1,
            BankAccountNo: 1,
            AccountNumber: 1,
            BankName: 1,
            IFSC: 1,
            Name: 1,
          },
        },
      },
    ]);
    return res
      .status(200)
      .json({ success: true, message: "Accountancy  data", data });
  } catch (error) {
    
    return next(error);
  }
};

const getAccountancyCheckAllModal = async (req, res, next) => {
  // Ledger=${Pos}&StartDate=${StartDate}&EndDate=${EndDate}&lookFor=${true}
  try {
    const { Ledger, EndDate, StartDate } = req.query;
    const data = await AccountancySchema.aggregate([
      {
        $match: {
          Ledger: ObjectId(Ledger),
          EntryDate: {
            $gte: StartDate,
            $lte: EndDate,
          },
        },
      },
      {
        $lookup: {
          from: "banks",
          localField: "oppositeLedger",
          foreignField: "_id",
          as: "oppositeLedger1",
        },
      },
      {
        $lookup: {
          from: "pos",
          localField: "oppositeLedger",
          foreignField: "_id",
          as: "oppositeLedger2",
        },
      },
      {
        $lookup: {
          from: "ledgerentries",
          localField: "oppositeLedger",
          foreignField: "_id",
          as: "oppositeLedger3",
        },
      },
      {
        $project: {
          _id: 1,
          VoucherType: 1,
          EntryDate: 1,
          RefNumber: 1,
          Remark: 1,
          Ledger: 1,
          oppositeLedger: 1,
          DR: 1,
          CR: 1,
          Amount: 1,
          CreatedWhich: 1,
          oppositeLedger: {
            $setUnion: [
              "$oppositeLedger1",
              "$oppositeLedger2",
              "$oppositeLedger3",
            ],
          },
        },
      },
      {
        $unwind: "$oppositeLedger",
      },
    ]);
    return res
      .status(200)
      .json({ success: true, message: "Accountancy  data", data });
  } catch (error) {
    
    return next(error);
  }
};

module.exports = {
  getAccountancy,
  getAccountancyCheckAllModal,
};
