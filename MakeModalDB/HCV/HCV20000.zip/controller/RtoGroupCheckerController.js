const RtoGroupCheckerSchema = require("../modal/RtoGroupCheckerSchema");
const PayoutGridSchema = require("../modal/PayoutGridModal");
const RTOSchema = require("../modal/RtoSchema");
const ErrorHandler = require("../util/handleError");
const { removeEmptyValues } = require("../util/UseFullFunctions");
const { ObjectId } = require("mongodb");

const getRtoGroupChecker = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;

    removeEmptyValues(restData, ["InsuranceCompany"]);

    const totalDocs = await RtoGroupCheckerSchema.find(
      inputData
        ? {
            $or: [
              {
                GroupName: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : { ...restData }
    ).countDocuments();
    const isDelete = await RtoGroupCheckerSchema.findByIdAndUpdate(
      "649c1d8fa3df7acfbc0ebc07",
      { $unset: { InsuranceType: "" } },
      { new: true }
    );

    const results = await RtoGroupCheckerSchema.find(
      inputData
        ? {
            $or: [
              {
                GroupName: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {
            ...restData,
          }
    )
      .populate("InsuranceCompany", "Name")
      .populate("ListOfRto", "RTOCode RTOName")
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: results,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};

const getRtoGroupSelectDrpDown = async (req, res, next) => {
  try {
    const { InsuranceCompany } = req.query;
    const results = await RtoGroupCheckerSchema.find(
      { InsuranceCompany: ObjectId(InsuranceCompany) },
      { GroupName: 1 }
    ).sort({ GroupName: 1 });

    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: results,
    });
  } catch (error) {
    return next(error);
  }
};
const postRtoGroupChecker = async (req, res, next) => {
  const { GroupName, InsuranceCompany, DEF, ListOfRto } = req.body;
  try {
    await RtoGroupCheckerSchema.create({
      GroupName,
      InsuranceCompany,
      DEF,
      ListOfRto,
      ListOfRtoLog: [
        {
          Date: ` ${DEF} - ${DEF}`,
          DEF: DEF,
          List: ListOfRto,
          Added: [],
          Removed: [],
        },
      ],
    });
    res.status(200).json({
      success: true,
      message: "RtoGroupChecker Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putRtoGroupChecker = async (req, res, next) => {
  const {
    OldListOfRto = [],
    ListOfRto = [],
    ListOfRtoLog = [],
    DateLog,
    preDEF,
    DEF,
    preListOfRto,
    ...restData
  } = req.body;
  const removed = [];
  const added = [...ListOfRto];
  OldListOfRto.forEach((element) => {
    const index = added.indexOf(element);
    if (index !== -1) {
      added.splice(index, 1);
    } else {
      removed.push(element);
    }
  });
  try {
    if (preDEF !== DEF || added.length > 0 || removed.length > 0) {
      await RtoGroupCheckerSchema.findByIdAndUpdate(
        req.params.id,
        {
          $set: {
            ListOfRto,
            ListOfRtoLog: [
              ...ListOfRtoLog,
              {
                Date: DateLog,
                List: ListOfRto,
                Added: added,
                DEF,
                Removed: removed,
              },
            ],
            ...restData,
          },
        },
        { new: true }
      );
    } else {
      await RtoGroupCheckerSchema.findByIdAndUpdate(
        req.params.id,
        {
          $set: {
            ListOfRto,
            ...restData,
          },
        },
        { new: true }
      );
    }

    // const data = await RtoGroupCheckerSchema.find({});
    // await data.forEach(async (ele) => {
    //   await RtoGroupCheckerSchema.findByIdAndUpdate(ele._id, {
    //     $set: {
    //       ListOfRtoLog: [
    //         {
    //           Date: ` ${ele.DEF} - ${ele.DEF}`,
    //           DEF: ele.DEF,
    //           List: ele.ListOfRto,
    //           Added: [],
    //           Removed: [],
    //         },
    //       ],
    //     },
    //   });
    // });
    // 
    return res.status(200).json({
      success: true,
      message: "RtoGroupChecker Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deleteRtoGroupChecker = async (req, res, next) => {
  try {
    const PayoutGrid = await PayoutGridSchema.findOne({
      RTOGroup: { $in: [ObjectId(req.params.id)] },
    });
    if (PayoutGrid) {
      return next(
        new ErrorHandler(
          `Data used in PaymentList Vouchers table so you can not delete`,
          400
        )
      );
    }
    await RtoGroupCheckerSchema.findByIdAndDelete(req.params.id);
    res
      .status(200)
      .json({ success: true, message: "RtoGroupChecker Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

const getDataById = async (req, res, next) => {
  try {
    const data = await RtoGroupCheckerSchema.findById(req.params.id)
      .populate("ListOfRto")
      .populate("ListOfRtoLog.Added", "RTOName RTOCode")
      .populate("ListOfRtoLog.Removed", "RTOName RTOCode");
    res
      .status(200)
      .json({ success: true, message: "RtoGroupChecked data", data });
  } catch (error) {
    return next(error);
  }
};
const testApi = async (req, res, next) => {
  try {
    const VehicleNumber = "PB70G9745";
    let RtoGroupCheckerData = [];
    if (VehicleNumber) {
      const RTO_Code = VehicleNumber.slice(0, 4);
      if (RTO_Code) {
        const RTO_DATA = await RTOSchema.findOne({
          RTOCode: RTO_Code,
        });
        
        if (RTO_DATA) {
          RtoGroupCheckerData = await RtoGroupCheckerSchema.aggregate([
            {
              $match: {
                InsuranceCompany: ObjectId("64a56a3d7c28f739725320f3"),
              },
            },
            {
              $unwind: "$ListOfRtoLog",
            },
            {
              $match: {
                "ListOfRtoLog.DEF": { $lte: new Date("2023-07-04") },
                "ListOfRtoLog.List": {
                  $elemMatch: { $eq: ObjectId(RTO_DATA?._id) },
                },
              },
            },
          ]);
        }
      }
    }

    res.status(200).json({
      success: true,
      message: "RtoGroupChecked kljhvg",
      data: RtoGroupCheckerData,
    });
  } catch (error) {
    return next(error);
  }
};
module.exports = {
  getRtoGroupChecker,
  postRtoGroupChecker,
  putRtoGroupChecker,
  deleteRtoGroupChecker,
  getDataById,
  testApi,
  getRtoGroupSelectDrpDown,
};
