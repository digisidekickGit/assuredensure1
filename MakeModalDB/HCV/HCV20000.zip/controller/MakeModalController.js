const { myMakeModalData } = require("../Output");
const MakeModalSchema = require("../modal/MakeModal");
const { ObjectId } = require("mongodb");
const fs = require("fs");
const { bikeData } = require("../Bike");
const { HCV2 } = require("../12000");
const { HCV3 } = require("../20000");
const { HCV4 } = require("../40000");


const CreateNewJsonFile = async (req, res, next) => {
  try {
    const MoreThen150 = [];
    const LessThen150 = [];

    const myData = JSON.parse(JSON.stringify(bikeData));
    myData.forEach((element) => {
      // const MAKE_Modal = element.Option;
      const VARIANT_DATA = element.Variant;
      // const pattern = /\(([^-]+)-([^,]+), ([^)]+)\)/;
      const pattern = /\((.*?)-(.*?)\)/;

      const matches = VARIANT_DATA.match(pattern);

      if (matches) {
        if (Number(matches[2].split("c")[0]) >= 150) {
          MoreThen150.push(element);
        } else {
          LessThen150.push(element);
        }
      }
    });

    const MoreThen150Data = JSON.stringify(MoreThen150);
    const LessThen150Data = JSON.stringify(LessThen150);
    fs.writeFile("LessThen150Data.json", LessThen150Data, "utf8", (err) => {
      if (err) {
        console.error("Error IN LessThen150Data writing JSON file:", err);
      } else {
        console.log(
          "JSON file LessThen150Data with array of objects has been created."
        );
      }
    });

    fs.writeFile("MoreThen150Data.json", MoreThen150Data, "utf8", (err) => {
      if (err) {
        console.error("Error IN MoreThen150Data writing JSON file:", err);
      } else {
        console.log(
          "JSON file MoreThen150Data with array of objects has been created."
        );
      }
    });
    return res.status(200).json({
      MoreThen150: MoreThen150,
      LessThen150: LessThen150,
      MoreThen150lEN: MoreThen150.length,
      LessThen150lEN: LessThen150.length,
    });
  } catch (error) {}
};

// const setMakeModalData = async (req, res, next) => {
//   try {
//     const isMyData = new Map();
//     const myData = JSON.parse(JSON.stringify(MoreThen150Data));
//     const notMatchContact = [];
//     myData.forEach((element) => {
//       const MAKE_Modal = element.Option;
//       const VARIANT_DATA = element.Variant;
//       // const pattern = /\(([^-]+)-([^,]+), ([^)]+)\)/;
//       const pattern = /\((.*?)-(.*?)\)/;
//       if (isMyData.has(MAKE_Modal)) {
//         const matches = VARIANT_DATA.match(pattern);
//         if (matches) {
//           const modalData = isMyData.get(MAKE_Modal);
//           isMyData.set(MAKE_Modal, [
//             ...modalData,
//             {
//               VariantName: VARIANT_DATA,
//               FuelType: matches[1],
//               Engine: matches[2],
//               // Seater: matches[3],
//             },
//           ]);
//         } else {
//           notMatchContact.push({ [MAKE_Modal]: VARIANT_DATA });
//         }
//       } else {
//         const matches = VARIANT_DATA.match(pattern);
//         if (matches) {
//           isMyData.set(MAKE_Modal, [
//             {
//               VariantName: VARIANT_DATA,
//               FuelType: matches[1],
//               Engine: matches[2],
//               // Seater: matches[3],
//             },
//           ]);
//         } else {
//           notMatchContact.push({ [MAKE_Modal]: VARIANT_DATA });
//         }
//       }
//     });
//     const MYdataIs = [...isMyData].map(([MakeModalName, VariantName]) => {
//       return {
//         Name: MakeModalName,
//         Variant: VariantName,
//         InsuranceType: ObjectId("64c7731247ecab0686f40e5d"),
//       };
//     });

//     await MakeModalSchema.insertMany(MYdataIs);
//     return res.status(200).json({
//       data: MYdataIs,
//       length: MYdataIs.length,
//       notMatchContact: notMatchContact,
//     });
//   } catch (error) {
//     return next(error);
//   }
// };

// const setMakeModalData = async (req, res, next) => {
//   try {
//     const isMyData = new Map();
//     const myData = JSON.parse(JSON.stringify(MSID));

//     myData.forEach((element) => {
//       const MAKE_Modal = element.Option;

//       if (isMyData.has(MAKE_Modal)) {
//         const modalData = isMyData.get(MAKE_Modal);
//         isMyData.set(MAKE_Modal, [
//           ...modalData,
//           {
//             VariantName: element?.Variant ?? "",
//             FuelType: element?.FuelType ?? "",
//             // Engine: matches[2],
//             // Seater: matches[3],
//           },
//         ]);
//       } else {
//         isMyData.set(MAKE_Modal, [
//           {
//             VariantName: element?.Variant ?? "",
//             FuelType: element?.FuelType ?? "",
//             // Engine: matches[2],
//             // Seater: matches[3],
//           },
//         ]);
//       }
//     });
//     const MYdataIs = [...isMyData].map(([MakeModalName, VariantName]) => {
//       return {
//         Name: MakeModalName,
//         Variant: VariantName,
//         InsuranceType: ObjectId("64a51e8bd8586cb6408c03c5"),
//       };
//     });

//     await MakeModalSchema.insertMany(MYdataIs);
//     return res.status(200).json({
//       data: MYdataIs,
//       length: MYdataIs.length,
//     });
//   } catch (error) {
//     return next(error);
//   }
// };
const setMakeModalData = async (req, res, next) => {
  try {
    const isMyData = new Map();
    const myData = JSON.parse(JSON.stringify(HCV4));

    myData.forEach((element) => {
      const MAKE_Modal = element.Company;

      if (isMyData.has(MAKE_Modal)) {
        const modalData = isMyData.get(MAKE_Modal);
        isMyData.set(MAKE_Modal, [
          ...modalData,
          {
            VariantName: `${element?.MakeModel}` ?? "",
            FuelType: "Diesel",
            // Engine:  element?.Watt,
            // Seater:  element?.SC,
          },
        ]);
      } else {
        isMyData.set(MAKE_Modal, [
          {
            VariantName: `${element?.MakeModel}` ?? "",
            FuelType: "Diesel",
            // Engine:  element?.Watt,
            // Seater:  element?.SC,
          },
        ]);
      }
    });
    const MYdataIs = [...isMyData].map(([MakeModalName, VariantName]) => {
      return {
        Name: MakeModalName,
        Variant: VariantName,
        InsuranceType: ObjectId("64e48542b43dd6235d971f31"),
      };
    });

    // await MakeModalSchema.insertMany(MYdataIs);
    // await MakeModalSchema.deleteMany({
    //   InsuranceType: ObjectId("64e746209448c21cba402239"),
    // });

    return res.status(200).json({
      data: MYdataIs,
      length: MYdataIs.length,
    });
  } catch (error) {
    return next(error);
  }
};

const getDataByField = async (req, res, next) => {
  const {
    FieldToShow = { Name: 1 },
    InsuranceType,
    inputData = "",
    page = 1,
    limit = 3000,
  } = req.body;

  let query = {};

  if (InsuranceType) {
    query["InsuranceType"] = ObjectId(InsuranceType);
  }

  if (inputData) {
    query["Name"] = { $regex: inputData, $options: "i" };
  }

  try {
    const data = await MakeModalSchema.find(
      {
        ...query,
      },
      { ...FieldToShow }
    )
      .skip((page - 1) * limit)
      .limit(limit);
    return res.status(200).json({
      data: data,
    });
  } catch (error) {}
};

const getDropDownData = async (req, res, next) => {
  const { inputData = "", InsuranceType, page = 1, limit = 150 } = req.body;

  let query = {};
  if (inputData) {
    query["Name"] = { $regex: inputData, $options: "i" };
  }
  if (InsuranceType) {
    query["InsuranceType"] = ObjectId(InsuranceType);
  }
  try {
    const data = await MakeModalSchema.aggregate([
      {
        $match: {
          ...query,
        },
      },
      {
        $skip: (page - 1) * limit,
      },
      {
        $limit: limit,
      },
      {
        $project: {
          value: "$_id",
          label: "$Name",
        },
      },
    ]);
    return res.status(200).json({
      data: data,
    });
  } catch (error) {}
};
const getFuelType = async (req, res, next) => {
  const { id } = req.body;
  try {
    const data = await MakeModalSchema.aggregate([
      {
        $match: {
          _id: ObjectId(id),
        },
      },
      {
        $unwind: "$Variant", // marge multiple docs in one array of objects
      },
      {
        $group: {
          _id: "$Variant.FuelType",
        },
      },
    ]);

    return res.status(200).json({
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      data: error,
    });
  }
};
const getVariant = async (req, res, next) => {
  const { Filter = {}, id } = req.body;
  try {
    const data = await MakeModalSchema.aggregate([
      {
        $match: {
          _id: ObjectId(id),
        },
      },
      {
        $unwind: "$Variant", // marge multiple docs in one array of objects
      },
      {
        $match: {
          ...Filter,
        },
      },
      {
        $group: {
          _id: "$Variant.VariantName",
        },
      },
    ]);
    return res.status(200).json({
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      data: error,
    });
  }
};

const getAllFuelType = async (req, res, next) => {
  try {
    const data = await MakeModalSchema.aggregate([
      { $unwind: "$Variant" },
      { $group: { _id: "$Variant.FuelType" } },
      { $group: { _id: null, FuelType: { $push: "$_id" } } },
    ]);
    console.log(data, "");
    return res.status(200).json({
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      data: error,
    });
  }
};

const db = async (req, res, next) => {
  try {
    const data = await MakeModalSchema.updateMany(
      {
        "Variant.FuelType": "2011",
        // _id: ObjectId("64ec8fa4f91d07302e920a35"),
      },
      {
        [`Variant.$.FuelType`]: "Petrol",
      }
    );
    return res.status(200).json({
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      data: error,
    });
  }
};

const getMakeModel = async (req, res, next) => {
  const {
    page = 1,
    limit = 5,
    inputData,
    InsuranceType,
    ...restData
  } = req.query;

  if (inputData) {
    restData["$or"] = [
      {
        Name: { $regex: inputData, $options: "i" },
      },
    ];
  }

  if (InsuranceType) {
    restData["InsuranceType"] = ObjectId(InsuranceType);
  }
  try {
    const totalDocs = await MakeModalSchema.find({
      ...restData,
    }).countDocuments();

    const results = await MakeModalSchema.find(
      { ...restData },
      { Name: 1, InsuranceType: 1 }
    )
      .populate("InsuranceType", "InsuranceType")
      .sort({ Name: 1 })
      .skip((page - 1) * limit)
      .limit(limit);
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: results,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};

const getDataById = async (req, res, next) => {
  const { id } = req.params;

  try {
    const data = await MakeModalSchema.findOne(
      { _id: ObjectId(id) },
      { InsuranceType: 1, Name: 1 }
    ).populate("InsuranceType", "InsuranceUnderFlow");

    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: data,
    });
  } catch (error) {}
};
const create = async (req, res, next) => {
  const { InsuranceType } = req.body;
  try {
    await MakeModalSchema.create(req.body);
    res.status(200).json({
      success: true,
      message: "Create Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const edit = async (req, res, next) => {
  try {
    await MakeModalSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    res.status(200).json({
      success: true,
      message: "Edit Successfully",
    });
  } catch (error) {
    return next(error);
  }
};

const getMakeModelSelectBox = async (req, res, next) => {
  const {
    page = 1,
    limit = 50,
    inputData,
    InsuranceType,
    ...restData
  } = req.query;

  if (inputData) {
    restData["$or"] = [
      {
        Name: { $regex: inputData, $options: "i" },
      },
    ];
  }

  if (InsuranceType) {
    restData["InsuranceType"] = ObjectId(InsuranceType);
  }
  try {
    const results = await MakeModalSchema.find({ ...restData }, { Name: 1 })
      .sort({ Name: 1 })
      .skip((page - 1) * limit)
      .limit(limit);
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: results,
    });
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getMakeModel,
  setMakeModalData,
  getDataByField,
  getFuelType,
  getVariant,
  getDropDownData,
  getAllFuelType,
  db,
  CreateNewJsonFile,
  getDataById,
  create,
  edit,
  getMakeModelSelectBox,
};
