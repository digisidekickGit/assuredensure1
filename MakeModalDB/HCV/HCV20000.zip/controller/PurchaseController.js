const PurchaseSchema = require("../modal/PurchaseSchema");
const PolicySchema = require("../modal/PolicySchema");
const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const { GST_ID_FOR_LEDGER } = require("../util/HardCodedDB");
// const puppeteer = require("puppeteer");
// const ejs = require("ejs");
const fs = require("fs");
const getPurchase = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, POS } = req.query;

    let query = {};

    if (inputData) {
      query["$or"] = [
        {
          ControlNumber: { $regex: inputData, $options: "i" },
        },
      ];
    }

    if (POS) {
      query["CreditAccount"] = ObjectId(POS);
    }

    const totalDocs = await PurchaseSchema.find({}).countDocuments();

    const results = await PurchaseSchema.find({})
      .sort({ PurchaseCode: 1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate({
        path: "CreditAccount",
        select: { Name: 1, PayoutCycle: 1, Club: 1 },
      })
      .populate({
        path: "DebitAccount",
        select: { Name: 1 },
      });
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: results,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
// (fuleType-1200wt, 5S)
const getGenerateReport = async (req, res, next) => {
  try {
    const data = await PurchaseSchema.findById(req.params.id).populate({
        path: "CreditAccount",
        select: {
          Name: 1,
          Salutation: 1,
          MiddleName: 1,
          PanNumber: 1,
          LastName: 1,
          GSTINNumber: 1,
          WDAddress: 1,
          WDLocality: 1,
          WDState: 1,
          WDCity: 1,
          WDPincode: 1,
          // BankDetails,
        },
        populate: {
          path: "ReportingTo",
          select: {
            Name: 1,
            Salutation: 1,
            MiddleName: 1,
            LastName: 1,
          },
        },
      })
      .populate({
        path: "DebitAccount",
        select: { Name: 1 },
      })
      .populate({
        path: "TDSAccount",
        select: { Name: 1 },
      })
      .populate({
        path: "Policy",
        populate: [
          {
            path: "POS",
            select: { Name: 1, PayoutCycle: 1, Club: 1 },
          },
          {
            path: "PolicyType",
            select: { Name: 1 },
          },
          {
            path: "InsuranceCompany",
            select: { Name: 1 },
          },
          {
            path: "InsuranceType",
            select: { InsuranceType: 1 },
          },
          {
            path: "MakeModal",
            select: { Name: 1 },
          },
          {
            path: "Broker",
            select: { Name: 1 },
          },
        ],
      });

    // const browser = await puppeteer.launch({
    //   headless: "new",
    // });

    // const page = await browser.newPage();

    // const htmlContent = await ejs.renderFile("views/pdf.ejs", {
    //   Data: data?.Policy ?? [],
    //   POS: data?.CreditAccount ?? {},
    //   ProcessingDate: data?.EnterDate ?? "",
    // });

    // await page.setContent(htmlContent);

    // const pdfBuffer = await page.pdf({
    //   format: "A4",
    //   printBackground: true,
    // });

    // await browser.close();
    // res.setHeader("Content-Disposition", "attachment; filename=myfile.pdf");
    // res.setHeader("Content-Type", "application/pdf");
    
    // res.status(200).send(Buffer.from(pdfBuffer));
    res.status(200).send("Working");
  } catch (error) {
    console.log(error);
    return next(error);
  }
};

const postPurchase = async (req, res, next) => {
  try {
    const {
      CreditAccount,
      DebitAccount,
      EnterDate,
      Remark,
      TDSPercent,
      TDSAccount,
      TDSAmount,
      GstAmount,
      TotalAmount,
      NetAmount,
      SelectedPolicyOpt,
    } = req.body;

    console.log(
      TDSAmount,
      "TDSAmount",
      GstAmount,
      "GstAmount",
      TotalAmount,
      "TotalAmount"
    );
    const CREATE_ACCOUNTANCY = [];

    const Arr = SelectedPolicyOpt.map((ele) => {
      return ObjectId(ele);
    });

    const que = {};
    if (DebitAccount) {
      que["DebitAccount"] = ObjectId(DebitAccount);
    }

    const totalDocs = await PurchaseSchema.find({}).countDocuments();
    let ControlNumber = `MZN${10000 + totalDocs}`;
    const PurchaseDetails = await PurchaseSchema.create({
      ControlNumber,
      CreditAccount,
      EnterDate,
      Remark,
      TDSPercent,
      TDSAccount,
      TotalAmount,
      NetAmount,
      Policy: Arr,
      ...que,
    });

    const CRForPOS = {
      VoucherType: "Purchase",
      CreatedWhich: PurchaseDetails?._id,
      EntryDate: EnterDate,
      Ledger: CreditAccount,
      oppositeLedger: DebitAccount,
      RefNumber: ControlNumber,
      Remark: Remark,
      DR: 0,
      CR: TotalAmount,
      Amount: TotalAmount,
    };
    const DRForPOS = {
      VoucherType: "Purchase",
      CreatedWhich: PurchaseDetails?._id,
      EntryDate: EnterDate,
      Ledger: DebitAccount,
      oppositeLedger: CreditAccount,
      RefNumber: ControlNumber,
      Remark: Remark,
      DR: 0,
      CR: TotalAmount,
      Amount: TotalAmount,
    };

    CREATE_ACCOUNTANCY.push(CRForPOS, DRForPOS);

    if (GstAmount) {
      const CRForGST = {
        VoucherType: "Purchase",
        CreatedWhich: PurchaseDetails?._id,
        EntryDate: EnterDate,
        Ledger: CreditAccount,
        oppositeLedger: GST_ID_FOR_LEDGER,
        RefNumber: ControlNumber,
        Remark: Remark,
        DR: 0,
        CR: GstAmount,
        Amount: GstAmount,
      };
      const DRForGST = {
        VoucherType: "Purchase",
        CreatedWhich: PurchaseDetails?._id,
        EntryDate: EnterDate,
        Ledger: GST_ID_FOR_LEDGER,
        oppositeLedger: CreditAccount,
        RefNumber: ControlNumber,
        Remark: Remark,
        DR: 0,
        CR: GstAmount,
        Amount: GstAmount,
      };
      CREATE_ACCOUNTANCY.push(CRForGST, DRForGST);
    }

    if (TDSAmount) {
      const CRForTDS = {
        VoucherType: "Purchase",
        CreatedWhich: PurchaseDetails?._id,
        EntryDate: EnterDate,
        Ledger: CreditAccount,
        oppositeLedger: TDSAccount,
        RefNumber: ControlNumber,
        Remark: Remark,
        DR: TDSAmount,
        CR: 0,
        Amount: TDSAmount,
      };
      const DRForTDS = {
        VoucherType: "Purchase",
        CreatedWhich: PurchaseDetails?._id,
        EntryDate: EnterDate,
        Ledger: TDSAccount,
        oppositeLedger: CreditAccount,
        RefNumber: ControlNumber,
        Remark: Remark,
        DR: TDSAmount,
        CR: 0,
        Amount: TDSAmount,
      };
      CREATE_ACCOUNTANCY.push(CRForTDS, DRForTDS);
    }

    await AccountancySchema.insertMany(CREATE_ACCOUNTANCY);

    await PolicySchema.updateMany(
      { _id: { $in: Arr } },
      {
        isPurchase: true,
      }
    );

    res.status(200).json({
      success: true,
      message: "Purchase Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putPurchase = async (req, res, next) => {
  const { DebitAccount, ...que } = req.body;

  if (DebitAccount) {
    que["DebitAccount"] = ObjectId(DebitAccount);
  }
  try {
    await PurchaseSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: que,
      },
      { new: true }
    );
    return res.status(200).json({
      success: true,
      message: "Purchase Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};

const getSingle = async (req, res, next) => {
  try {
    const data = await PurchaseSchema.findById(req.params.id)
      .populate({
        path: "CreditAccount",
        select: {
          Name: 1,
          Salutation: 1,
          MiddleName: 1,
          LastName: 1,
          GSTINNumber: 1,
        },
      })
      .populate({
        path: "DebitAccount",
        select: { Name: 1 },
      })
      .populate({
        path: "TDSAccount",
        select: { Name: 1 },
      })
      .populate({
        path: "Policy",
        populate: [
          {
            path: "POS",
            select: { Name: 1, PayoutCycle: 1, Club: 1 },
          },
          {
            path: "PolicyType",
            select: { Name: 1 },
          },
          {
            path: "InsuranceCompany",
            select: { Name: 1 },
          },
          {
            path: "InsuranceType",
            select: { InsuranceType: 1 },
          },
          {
            path: "MakeModal",
            select: { Name: 1 },
          },
          {
            path: "Broker",
            select: { Name: 1 },
          },
        ],
      });

    return res.status(200).json({
      success: true,
      message: "Purchase Data",
      data,
    });
  } catch (error) {
    return next(error);
  }
};
const deletePurchase = async (req, res, next) => {
  try {
    const data = await PurchaseSchema.findByIdAndDelete(req.params.id);
    await PolicySchema.updateMany(
      { _id: { $in: data.Policy ?? [] } },
      {
        isPurchase: false,
      }
    );

    await AccountancySchema.deleteMany({
      CreatedWhich: data._id,
    });
    res
      .status(200)
      .json({ success: true, message: "Purchase Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

const getIsPurchase = async (req, res, next) => {
  const { POS } = req.body;
  const que = { Status: "APPROVED", isPurchase: false };
  if (POS) {
    que["POS"] = ObjectId(POS);
  }
  try {
    const Policy = await PolicySchema.aggregate([
      {
        $match: {
          ...que,
        },
      },
      {
        $project: {
          PolicyType: 0,
          // InsuranceCompany: 0,
          // InsuranceType: 0,
          InsuranceUnderFlow: 0,
          // RSD: 0,
          IMTType: 0,
          FuelType: 0,
          BusinessType: 0,
          YearOfManufacture: 0,
          // PaymentMode: 0,
          NCB: 0,
          BusinessType: 0,
          YearOfManufacture: 0,
          Variant: 0,
          RegistrationDate: 0,
          NewPolicyCopy: 0,
          Broker: 0,
          Broker: 0,
          MakeModal: 0,
          RC1: 0,
          RC2: 0,
          PreviousPolicy1: 0,
          PreviousPolicy2: 0,
          createdAt: 0,
          updatedAt: 0,
          __v: 0,
        },
      },
    ]);
    const TotalAmount = await PolicySchema.aggregate([
      {
        $match: {
          ...que,
        },
      },
      {
        $project: {
          PolicyType: 0,
          InsuranceCompany: 0,
          InsuranceType: 0,
          InsuranceUnderFlow: 0,
          RSD: 0,
          IMTType: 0,
          FuelType: 0,
          BusinessType: 0,
          YearOfManufacture: 0,
          PaymentMode: 0,
          NCB: 0,
          BusinessType: 0,
          YearOfManufacture: 0,
          Variant: 0,
          RegistrationDate: 0,
          NewPolicyCopy: 0,
          Broker: 0,
          Broker: 0,
          MakeModal: 0,
          RC1: 0,
          RC2: 0,
          PreviousPolicy1: 0,
          PreviousPolicy2: 0,
          createdAt: 0,
          updatedAt: 0,
          __v: 0,
        },
      },
      {
        $group: {
          _id: null,
          AmountToPay: { $sum: "$Commission.TotalAmountToPay" },
        },
      },
    ]);
    let PurchaseData = await PolicySchema.populate(Policy, [
      {
        path: "POS",
        select: { Name: 1, PayoutCycle: 1, Club: 1 },
      },
      {
        path: "InsuranceCompany",
        select: { Name: 1 },
      },
      {
        path: "InsuranceType",
        select: { InsuranceType: 1 },
      },
    ]);
    res.status(200).json({
      success: true,
      data: PurchaseData,
      TotalAmount: TotalAmount[0],
      message: "get Approved Policy",
    });
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getPurchase,
  postPurchase,
  putPurchase,
  deletePurchase,
  getIsPurchase,
  getSingle,
  getGenerateReport,
};
