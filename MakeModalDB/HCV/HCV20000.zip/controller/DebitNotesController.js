const PaymentListSchema = require("../modal/PaymentListSchema");
const DebitNotesSchema = require("../modal/DebitNotesSchema");
const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const getDebitNotes = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;

    const totalDocs = await DebitNotesSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    ).countDocuments();

    const DebitNotes = await DebitNotesSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    )
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: DebitNotes,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
const postDebitNotes = async (req, res, next) => {
  try {
    
    const data = await DebitNotesSchema.create(req.body);
    
    await data.DebitNotes.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Remark: data?.Remark ?? "",
        Ledger: data.PartyAccountLedger, // RAVI
        oppositeLedger: element.PartyAccount, // HDFC
        RefNumber: element.RefNumber,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Remark: data.Remark,
        Ledger: element.PartyAccount, // HDFC
        oppositeLedger: data.PartyAccountLedger,
        RefNumber: element.RefNumber, // HDFC
        DR: element.Account,
        CR: 0,
        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "DebitNotes Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putDebitNotes = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    const data = await DebitNotesSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    try {
      await data.DebitNotes.forEach(async (element) => {
        const AccountancyCR = {
          VoucherType: data.voucherType,
          CreatedWhich: data._id,
          EntryDate: data.EntryDate,
          Remark: data?.Remark ?? "",
          Ledger: data.PartyAccountLedger, // RAVI
          oppositeLedger: element.PartyAccount, // HDFC
          RefNumber: element.RefNumber,
          DR: 0,
          CR: element.Account,
          Amount: element.Account,
        };
        const AccountancyDR = {
          VoucherType: data.voucherType,
          CreatedWhich: data._id,
          EntryDate: data.EntryDate,
          Remark: data.Remark,
          Ledger: element.PartyAccount, // HDFC
          oppositeLedger: data.PartyAccountLedger, // RAVI
          RefNumber: element.RefNumber, // HDFC
          DR: element.Account,
          CR: 0,
          Amount: element.Account,
        };
        await AccountancySchema.create(AccountancyCR);
        await AccountancySchema.create(AccountancyDR);
      });
    } catch (error) {}

    res.status(200).json({
      success: true,
      message: "DebitNotes Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deleteDebitNotes = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    await DebitNotesSchema.findByIdAndDelete(req.params.id);
    // 
    return res
      .status(200)
      .json({ success: true, message: "DebitNotes Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

const getDebitNotesByPopulate = async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 3000,
      inputData = undefined,
      ...restData
    } = req.query;

    const Search = inputData
      ? {
          Remark: { $regex: inputData, $options: "i" },
        }
      : {};
    const data = await DebitNotesSchema.aggregate([
      {
        $match: Search,
      },
      // { $skip: 1 },
      // { $limit: 1 },
      {
        $unwind: "$DebitNotes",
      },
      {
        $lookup: {
          from: "ledgerentries",
          localField: "DebitNotes.PartyAccount",
          foreignField: "_id",
          as: "DebitNotes.PartyAccount1",
        },
      },
      {
        $lookup: {
          from: "pos",
          localField: "DebitNotes.PartyAccount",
          foreignField: "_id",
          as: "DebitNotes.PartyAccount2",
        },
      },
      {
        $project: {
          EntryDate: 1,
          PartyAccountLedger: 1,
          _id: 1,
          EntryDate: 1,
          PartyAccountLedger: 1,
          Remark: 1,
          voucherType: 1,
          DebitNotes: {
            PartyAccount: {
              // _id: 1,
              // Name: 1,
              $setUnion: [
                "$DebitNotes.PartyAccount1",
                "$DebitNotes.PartyAccount2",
              ],
            },
            Account: 1,
            RefNumber: 1,
            key: 1,
            _id: 1,
          },
        },
      },
      {
        $project: {
          EntryDate: 1,
          PartyAccountLedger: 1,
          _id: 1,
          EntryDate: 1,
          PartyAccountLedger: 1,
          Remark: 1,
          voucherType: 1,
          DebitNotes: {
            PartyAccount: {
              _id: 1,
              Name: 1,
            },
            Account: 1,
            RefNumber: 1,
            key: 1,
            _id: 1,
          },
        },
      },
      {
        $unwind: "$DebitNotes.PartyAccount",
      },
    ]);
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: data,
      // totalDocs: data.length,
    });
  } catch (error) {
    return next(error);
  }
};
module.exports = {
  getDebitNotes,
  postDebitNotes,
  putDebitNotes,
  deleteDebitNotes,
  getDebitNotesByPopulate,
};
