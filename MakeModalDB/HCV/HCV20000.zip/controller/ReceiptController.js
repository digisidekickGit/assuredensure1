const PaymentListSchema = require("../modal/PaymentListSchema");
const ReceiptSchema = require("../modal/ReceiptSchema");
const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const getReceipt = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;
    
    const totalDocs = await ReceiptSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    ).countDocuments();

    const Receipt = await ReceiptSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    )
      .skip((page - 1) * limit)
      .limit(limit)
      .populate({
        path: "Receipt.PartyAccount",
        select: "Name", //"Name Email"
      });
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: Receipt,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
const postReceipt = async (req, res, next) => {
  try {
    const data = await ReceiptSchema.create(req.body);
    await data.Receipt.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data.CashBankAccount, // HDFC
        RefNumber: element.RefNumber,
        Remark: element.Remark,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: data.CashBankAccount, // HDFC
        oppositeLedger: element.PartyAccount, // RAVI
        RefNumber: element.RefNumber, // HDFC
        Remark: element.Remark,
        DR: element.Account,
        CR: 0,
        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });

    res.status(200).json({
      success: true,
      message: "Receipt Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putReceipt = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    const data = await ReceiptSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    await data.Receipt.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data.CashBankAccount, // HDFC
        RefNumber: element.RefNumber,
        Remark: element.Remark,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        
        Ledger: data.CashBankAccount, // HDFC
        oppositeLedger: element.PartyAccount, // RAVI
        RefNumber: element.RefNumber, // HDFC
        Remark: element.Remark,
        DR: element.Account,
        CR: 0,

        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "Receipt Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deleteReceipt = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    await ReceiptSchema.findByIdAndDelete(req.params.id);
    // 
    return res
      .status(200)
      .json({ success: true, message: "Receipt Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

const getLedger = async (req, res, next) => {
  try {
    // 6470485aebe5a93871211410 => POS ID
    const { StartDate, Ledger, EndDate, isBank = false } = req.query;
    let Receipt;
    let payment;
    if (isBank) {
      Receipt = await ReceiptSchema.aggregate([
        {
          $match: {
            // EntryDate: {
            //   $gte: StartDate,
            //   $lte: EndDate,
            // },
          },
        },
        {
          $project: {
            // createdAt: 1,
            _id: 1,
            EntryDate: 1,
            CashBankAccount: 1,
            Remark: 1,
            voucherType: 1,
            ledger: {
              $filter: {
                input: "$Receipt",
                as: "act",
                cond: {
                  $eq: [`$$act.PartyAccount`, ObjectId(Ledger)],
                },
              },
            },
          },
        },
        {
          $unwind: "$ledger", // marge multiple docs in one array of objects
        },
        {
          $lookup: {
            from: "banks",
            localField: "CashBankAccount",
            foreignField: "_id",
            as: "CashBankAccount",
          },
        },
        {
          $unwind: "$CashBankAccount", // marge multiple docs in one array of objects
        },
      ]);
      payment = await PaymentListSchema.aggregate([
        {
          $match: {
            EntryDate: {
              $gte: StartDate,
              $lte: EndDate,
            },
          },
        },
        {
          $project: {
            // createdAt: 1,
            _id: 1,
            EntryDate: 1,
            CashBankAccount: 1,
            Remark: 1,
            voucherType: 1,
            ledger: {
              $filter: {
                input: "$PaymentList",
                as: "act",
                cond: {
                  $eq: [`$$act.PartyAccount`, ObjectId(Ledger)],
                },
              },
            },
          },
        },
        {
          $unwind: "$ledger", // marge multiple docs in one array of objects
        },
        {
          $lookup: {
            from: "banks",
            localField: "CashBankAccount",
            foreignField: "_id",
            as: "CashBankAccount",
          },
        },
        {
          $unwind: "$CashBankAccount", // marge multiple docs in one array of objects
        },
      ]);
    } else {
      Receipt = await ReceiptSchema.aggregate([
        {
          $match: {
            // EntryDate: {
            //   $gte: StartDate,
            //   $lte: EndDate,
            // },
            // CashBankAccount: Ledger,
          },
        },
        {
          $unwind: "$Receipt", // marge multiple docs in one array of objects
        },
        {
          $lookup: {
            from: "pos",
            localField: "Receipt.PartyAccount",
            foreignField: "_id",
            as: "ledger",
          },
        },
        {
          $unwind: "$ledger", // marge multiple docs in one array of objects
        },
        {
          $project: {
            // createdAt: 1,
            _id: 1,
            EntryDate: 1,
            CashBankAccount: 1,
            Remark: 1,
            voucherType: 1,
            // Receipt: 1,
            ledger: {
              Name: 1,
              Email: 1,
              BankAccountNo: 1,
              BankName: 1,
              IFSC: 1,
              Amount: "$Receipt.Account",
              RefNumber: "$Receipt.RefNumber",
              // PartyAccount
            },
          },
        },
      ]);
      payment = await PaymentListSchema.aggregate([
        {
          $match: {
            // EntryDate: {
            //   $gte: StartDate,
            //   $lte: EndDate,
            // },
            // CashBankAccount: Ledger,
          },
        },
        {
          $unwind: "$PaymentList", // marge multiple docs in one array of objects
        },

        {
          $lookup: {
            from: "pos",
            localField: "PaymentList.PartyAccount",
            foreignField: "_id",
            as: "ledger",
          },
        },
        {
          $unwind: "$ledger", // marge multiple docs in one array of objects
        },
        {
          $project: {
            // createdAt: 1,
            _id: 1,
            EntryDate: 1,
            CashBankAccount: 1,
            Remark: 1,
            voucherType: 1,
            ledger: {
              Name: 1,
              Email: 1,
              BankAccountNo: 1,
              BankName: 1,
              IFSC: 1,
              Amount: "$PaymentList.Account",
              RefNumber: "$PaymentList.RefNumber",
            },
            // PartyAccount
          },
        },
      ]);
    }

    res.status(200).json({
      success: true,
      message: "get Ledger",
      data: [...Receipt, ...payment],
    });
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getReceipt,
  postReceipt,
  putReceipt,
  deleteReceipt,
  getLedger,
};
