const PaymentListSchema = require("../modal/PaymentListSchema");
const CreditNotesSchema = require("../modal/CreditNotesSchema");
const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const getCreditNotes = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;

    const totalDocs = await CreditNotesSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    ).countDocuments();

    const CreditNotes = await CreditNotesSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    )
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: CreditNotes,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
const postCreditNotes = async (req, res, next) => {
  try {
    
    const data = await CreditNotesSchema.create(req.body);
    
    await data.CreditNotes.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Remark: data?.Remark ?? "",
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data.PartyAccountLedger, // HDFC
        RefNumber: element.RefNumber,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Remark: data.Remark,
        Ledger: data.PartyAccountLedger, // HDFC
        oppositeLedger: element.PartyAccount, // RAVI
        RefNumber: element.RefNumber, // HDFC
        DR: element.Account,
        CR: 0,
        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "CreditNotes Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putCreditNotes = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    const data = await CreditNotesSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    try {
      await data.CreditNotes.forEach(async (element) => {
        const AccountancyCR = {
          VoucherType: data.voucherType,
          CreatedWhich: data._id,
          EntryDate: data.EntryDate,
          Remark: data?.Remark ?? "",
          Ledger: element.PartyAccount, // RAVI
          oppositeLedger: data.PartyAccountLedger, // HDFC
          RefNumber: element.RefNumber,
          DR: 0,
          CR: element.Account,
          Amount: element.Account,
        };
        const AccountancyDR = {
          VoucherType: data.voucherType,
          CreatedWhich: data._id,
          EntryDate: data.EntryDate,
          Remark: data.Remark,
          Ledger: data.PartyAccountLedger, // HDFC
          oppositeLedger: element.PartyAccount, // RAVI
          RefNumber: element.RefNumber, // HDFC
          DR: element.Account,
          CR: 0,
          Amount: element.Account,
        };
        await AccountancySchema.create(AccountancyCR);
        await AccountancySchema.create(AccountancyDR);
      });
    } catch (error) {}

    res.status(200).json({
      success: true,
      message: "CreditNotes Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deleteCreditNotes = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    await CreditNotesSchema.findByIdAndDelete(req.params.id);
    // 
    return res
      .status(200)
      .json({ success: true, message: "CreditNotes Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

const getCreditNotesByPopulate = async (req, res, next) => {
  try {
    const {
      page = 1,
      limit = 3000,
      inputData = undefined,
      ...restData
    } = req.query;

    const Search = inputData
      ? {
          Remark: { $regex: inputData, $options: "i" },
        }
      : {};
    const data = await CreditNotesSchema.aggregate([
      {
        $match: Search,
      },
      // { $skip: 1 },
      // { $limit: 1 },
      {
        $unwind: "$CreditNotes",
      },
      {
        $lookup: {
          from: "ledgerentries",
          localField: "CreditNotes.PartyAccount",
          foreignField: "_id",
          as: "CreditNotes.PartyAccount1",
        },
      },
      {
        $lookup: {
          from: "pos",
          localField: "CreditNotes.PartyAccount",
          foreignField: "_id",
          as: "CreditNotes.PartyAccount2",
        },
      },
      {
        $project: {
          EntryDate: 1,
          PartyAccountLedger: 1,
          _id: 1,
          EntryDate: 1,
          PartyAccountLedger: 1,
          Remark: 1,
          voucherType: 1,
          CreditNotes: {
            PartyAccount: {
              // _id: 1,
              // Name: 1,
              $setUnion: [
                "$CreditNotes.PartyAccount1",
                "$CreditNotes.PartyAccount2",
              ],
            },
            Account: 1,
            RefNumber: 1,
            key: 1,
            _id: 1,
          },
        },
      },
      {
        $project: {
          EntryDate: 1,
          PartyAccountLedger: 1,
          _id: 1,
          EntryDate: 1,
          PartyAccountLedger: 1,
          Remark: 1,
          voucherType: 1,
          CreditNotes: {
            PartyAccount: {
              _id: 1,
              Name: 1,
            },
            Account: 1,
            RefNumber: 1,
            key: 1,
            _id: 1,
          },
        },
      },
      {
        $unwind: "$CreditNotes.PartyAccount",
      },
    ]);
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: data,
      // totalDocs: data.length,
    });
  } catch (error) {
    return next(error);
  }
};
module.exports = {
  getCreditNotes,
  postCreditNotes,
  putCreditNotes,
  deleteCreditNotes,
  getCreditNotesByPopulate,
};
