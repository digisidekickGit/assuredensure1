const PaymentListSchema = require("../modal/PaymentListSchema");
const ContraSchema = require("../modal/ContraSchema");
const AccountancySchema = require("../modal/AccountancySchema");
const { ObjectId } = require("mongodb");
const getContra = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;
    
    const totalDocs = await ContraSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    ).countDocuments();

    const Contra = await ContraSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    )
      .skip((page - 1) * limit)
      .limit(limit)
      .populate({
        path: "Contra.PartyAccount",
        select: "BankName", //"Name Email"
      });
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: Contra,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
const postContra = async (req, res, next) => {
  try {
    const data = await ContraSchema.create(req.body);
    await data.Contra.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data.CashBankAccount, // HDFC
        RefNumber: element.RefNumber,
        Remark: element.Remark,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: data.CashBankAccount, // HDFC
        oppositeLedger: element.PartyAccount, // RAVI
        RefNumber: element.RefNumber, // HDFC
        Remark: element.Remark,
        DR: element.Account,
        CR: 0,
        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });

    res.status(200).json({
      success: true,
      message: "Contra Created Successfully",
    });
  } catch (error) {
    return next(error);
  }
};
const putContra = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    const data = await ContraSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    await data.Contra.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,
        Ledger: data.CashBankAccount, // RAVI
        oppositeLedger: element.PartyAccount, // HDFC
        RefNumber: element.RefNumber,
        Remark: element.Remark,
        DR: element.Account,
        CR: 0,
        Amount: element.Account,
      };
      const AccountancyDR = {
        VoucherType: data.voucherType,
        CreatedWhich: data._id,
        EntryDate: data.EntryDate,

        Ledger: element.PartyAccount, // HDFC
        oppositeLedger: data.CashBankAccount, // RAVI
        RefNumber: element.RefNumber, // HDFC
        Remark: element.Remark,
        DR: 0,
        CR: element.Account,
        Amount: element.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "Contra Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deleteContra = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    await ContraSchema.findByIdAndDelete(req.params.id);
    // 
    return res
      .status(200)
      .json({ success: true, message: "Contra Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getContra,
  postContra,
  putContra,
  deleteContra,
};
