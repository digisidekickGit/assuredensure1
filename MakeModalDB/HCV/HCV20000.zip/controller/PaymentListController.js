const AccountancySchema = require("../modal/AccountancySchema");
const PaymentListSchema = require("../modal/PaymentListSchema");

const getPaymentList = async (req, res, next) => {
  try {
    const { page = 1, limit = 3000, inputData, ...restData } = req.query;
    const totalDocs = await PaymentListSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    ).countDocuments();

    const PaymentList = await PaymentListSchema.find(
      inputData
        ? {
            $or: [
              {
                Remark: { $regex: inputData, $options: "i" },
              },
            ],
          }
        : {}
    )
      .skip((page - 1) * limit)
      .limit(limit)
      .populate({
        path: "PaymentList.PartyAccount",
        select: "Name Email BankAccountNo BankName IFSC",
      })
      .populate({
        path: "CashBankAccount",
        select: "BankName",
      });
    res.status(200).json({
      success: true,
      message: "Fetched Successfully",
      data: PaymentList,
      totalDocs,
    });
  } catch (error) {
    return next(error);
  }
};
const postPaymentList = async (req, res, next) => {
  try {
    const data = await PaymentListSchema.create(req.body);
    await data.PaymentList.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data?.voucherType,
        CreatedWhich: data?._id,
        EntryDate: data.EntryDate,
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data?.CashBankAccount, // HDFC
        RefNumber: element?.RefNumber,
        Remark: element.Remark,
        DR: element?.Account,
        CR: 0,
        Amount: element?.Account,
      };
      const AccountancyDR = {
        VoucherType: data?.voucherType,
        CreatedWhich: data?._id,
        EntryDate: data.EntryDate,
        Ledger: data?.CashBankAccount, // HDFC
        oppositeLedger: element?.PartyAccount, // RAVI
        RefNumber: element?.RefNumber,
        Remark: element.Remark,
        DR: 0,
        CR: element?.Account,
        Amount: element?.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "PaymentList Created Successfully",
    });
  } catch (error) {
    
    return next(error);
  }
};
const putPaymentList = async (req, res, next) => {
  try {
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    const data = await PaymentListSchema.findByIdAndUpdate(
      req.params.id,
      {
        $set: req.body,
      },
      { new: true }
    );
    await data.PaymentList.forEach(async (element) => {
      const AccountancyCR = {
        VoucherType: data?.voucherType,
        CreatedWhich: data?._id,
        EntryDate: data.EntryDate,
        Ledger: element.PartyAccount, // RAVI
        oppositeLedger: data?.CashBankAccount, // HDFC
        RefNumber: element?.RefNumber,
        Remark: element.Remark,
        DR: element?.Account,
        CR: 0,
        Amount: element?.Account,
      };
      const AccountancyDR = {
        VoucherType: data?.voucherType,
        CreatedWhich: data?._id,
        EntryDate: data.EntryDate,
        Ledger: data?.CashBankAccount, // HDFC
        oppositeLedger: element?.PartyAccount, // RAVI
        RefNumber: element?.RefNumber,
        Remark: element.Remark,
        DR: 0,
        CR: element?.Account,
        Amount: element?.Account,
      };
      await AccountancySchema.create(AccountancyCR);
      await AccountancySchema.create(AccountancyDR);
    });
    res.status(200).json({
      success: true,
      message: "PaymentList Updated Successful",
    });
  } catch (error) {
    return next(error);
  }
};
const deletePaymentList = async (req, res, next) => {
  try {
    // const PayoutGrid = await PayoutGridSchema.findOne({
    //   PaymentList: { $in: req.params.id },
    // });
    // const Policy = await PolicySchema.findOne({
    //   PaymentList: req.params.id,
    // });

    // if (Policy) {
    //   return next(
    //     new ErrorHandler(
    //       `Data used in another Policy table so you can not delete`,
    //       400
    //     )
    //   );
    // }
    // if (PayoutGrid) {
    //   return next(
    //     new ErrorHandler(
    //       `Data used in another PayoutGrid table so you can not delete`,
    //       400
    //     )
    //   );
    // }
    await AccountancySchema.deleteMany({
      CreatedWhich: req.params.id,
    });
    await PaymentListSchema.findByIdAndDelete(req.params.id);
    return res
      .status(200)
      .json({ success: true, message: "PaymentList Deleted Successfully" });
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getPaymentList,
  postPaymentList,
  putPaymentList,
  deletePaymentList,
};
