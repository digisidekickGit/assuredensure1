const GCV4 =[
 {
  "Company": "Piaggio",
  "Variant": "Porter 1000 (1892 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Minitruck Gvw 1870 (1870 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Minitruck Gvw 1870. (1870 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "P601 (1850 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Plus (1815 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Cargo Van (1815 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Cargo Van Bs4 (1815 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Truk Plus. (1810 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Truk Plus (1810 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Load Cng (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Bs Iv. (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Load (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Vx (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Cng (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Load Rd (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Maxximo Bs Iv (1800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Minitruck Cng (1770 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Supro Minitruck (1770 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "265 Dlx (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Ex Solid E-ii (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Express Cargo E-ii (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Dx Solid E-ii (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Dx Mettallic E-ii (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Lifeline E-ii (1750 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Sigma Sigma Ex Mettalic E-ii (1750 GVW)"
 },
 {
  "Company": "Agriking Tractors",
  "Variant": "Agri King 20-55 (1750 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Facelift Gvw 1700 (1700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Facelift Gvw 1700. (1700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper 1.8 Cum Ace Hopper Tipper (1700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Dicor (1670 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "M4 M4 (1660 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "M4 M4. (1660 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Trump 15 Trump 15 (1660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Gvw 1630 (1630 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Xl Bs Iv. (1630 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Xl (1630 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Magic (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry Std Cng. (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry Std (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry Std Gvw 1600. (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry Std Gvw 1600 (1600 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Super Carry Std Cng (1600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Facelift. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ace Cng. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Gold Bs4 (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Fbv Shutter (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Facelift (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ace Ex (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht High Deck (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace 275 Idi (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ace Fx (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ace (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Gold Bsiv Gvw 1550 (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ex Gvw 1550 (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht Refresh. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Ht. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Hd (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace 275 Idi. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Cng Ace Cng (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Zip (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Zip. (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Dumper Ace Dumper (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker Ace (1550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Null Ace Ht (1550 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Truk Mark 1. (1550 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Mini Truck (1550 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Truk Mark 1 (1550 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Minidor Range Minidor Metal Top D.v. (1550 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Eeco Cargo (1540 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Eeco Flexi Green (1540 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Eeco Cargo Cng (1540 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7 16 Bs4 Cng (1485 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto S6-11 Gvw 1485 (1485 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Porter 700 (1475 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L6-16 Gvw 1420 (1420 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7-16 Gvw 1420 (1420 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L7-16 Gvw 1410 (1410 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7-11 Gvw 1408 (1408 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Omni Cargo Omni Cargo (1400 GVW)"
 },
 {
  "Company": "Maruti",
  "Variant": "Omni Cargo Lpg Omni Cargo Lpg (1400 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Champion Load Carrier Cng. (1350 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Champion Load Carrier (1350 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Champion Pick-up Van (1350 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Mahindra Champion Load Carrier Cng (1350 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Minidor (1350 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Minidor Pick Up Van (1350 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Minidor Range Minidor Metal Top P.up Without Door (1350 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Minidor Range (1350 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Minidor Range Minidor Chassis With Cowl (1350 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Zip Xl Bs Iv (1310 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Porter. (1300 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Porter (1300 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Porter 600 (1300 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L6-16 Gvw 1285 (1285 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto S6-16 Gvw 1285 (1285 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto S6-11 Gvw 1285 (1285 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Zip Bs Iv. (1285 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Ace Zip Fsd (1285 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Auto Rickshaw Delivery Van (1200 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Mx Premium (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Ax Plus (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Mx Plus (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Mx (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix N1 Pro (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Ax (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix N1 (1150 GVW)"
 },
 {
  "Company": "Eicher Polaris",
  "Variant": "Multix Mx Super (1150 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Gio Gio (1110 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Gio Delivery Van (1110 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Mini (1100 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alfa Pickup Diesel (Without Door) (1060 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alfa Load Carrier (1060 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alfa Cargo Platform (1060 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Champion Alfa Cargo (1060 GVW)"
 },
 {
  "Company": "A.p.i. Motors Private Limited",
  "Variant": "Api Garv (Re) Loader (1000 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Max Delivery Van (999 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alfa Plus (995 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alfa Lc Plus (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Cng Delivery Van Gc 1000 Cng Delivery Van (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Cng Hi Deck Gc 1000 Cng Hi Deck (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 205 Cng Pick Up Van (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re Pick Up Re Pick Up (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Sgc 1000 Hi Dek Sgc 1000 Hi Dek (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Cargo Pv (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Premium Xl Dv (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Cargo Xl. (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Cargo Xl (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Xl Hd (995 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Gem Cargo (995 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Dumper Gc Max Dumper (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Cng Dac Gc 1000 Cng Dac (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Cng Pick Up Van Gc 1000 Cng Pick Up Van (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Dac Gc 1000 Dac (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc 1000 Pick Up Gc 1000 Pick Up (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Max Gvw 990 (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Max (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Max Gc Max (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Max Hi Deck Gc Max Hi Deck (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re Maxima Cargo Bsiv (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re Maxima Cargo Cng (990 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re Maxima Cargo (990 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Atul Shakti Delivery Van Bsiv (990 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Atul Shakti Delivery Van (990 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Atul Shakti Smart (990 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Atul Shakti High Deck Bsiv (990 GVW)"
 },
 {
  "Company": "Atul",
  "Variant": "Atul Shakti Pickup Van (990 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape H\/b Cng (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Hopper (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Xtra Ldx Gvw 975 (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape D600 P\/v (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Cargo D600 Pick Up (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Xtra Ld (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Xtra Ld Cng (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape P\/v Ld Cng (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Ape Pick-up Van Xld (975 GVW)"
 },
 {
  "Company": "Piaggio",
  "Variant": "Tipper Ape 1 Tonner Tipper (975 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re Diesle Mega Re Diesle Mega (876 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Alpha Load Cng Champion Alfa Load Carrier (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Gc Re 600 Delivery Van (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re - 600 Re - 600 (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 600 Dsl Loading (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 600 Cargo (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 600 Loading (800 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 600 Cng (800 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7-16 (726 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L7-11 (700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L7-16 (700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7-16. (700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto X7-11 (700 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto S6-11 (600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto S6-16 (600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L6-11 (600 GVW)"
 },
 {
  "Company": "Mahindra",
  "Variant": "Jeeto L6-16 (600 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re4s Lps Re4s Lps (340 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 4s Petrol Re 4s Petrol (305 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Re 2 S Re 2 S (277 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Milk Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Null 407 Pick Up (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Sfc 407 Pick Up (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Sfc 407 Pick Up. (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Ex\/31 Ht (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Refrigerator Van Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc 407 Refrigerator Van (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/cab\/ex\/eii Sfc\/407\/31\/cab\/ex\/eii (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/cab\/ex\/eii Sfc\/407\/31\/cab\/ex\/eii (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/clb\/ex\/eii Sfc\/407\/31\/clb\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/clb\/ex\/eii Sfc\/407\/31\/clb\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex\/eii Sfc\/407\/31\/hd\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex\/eii Sfc\/407\/31\/hd\/ex\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex2\/ps\/eii Sfc\/407\/31\/hd\/ex2\/ps\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/407\/31\/hd\/ex2\/ps\/eii Sfc\/407\/31\/hd\/ex2\/ps\/eii (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/cab\/ex\/eii Sfc\/709\/38\/cab\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/cab\/ex\/eii Sfc\/709\/38\/cab\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/clb\/ex\/eii Sfc\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/clb\/ex\/eii Sfc\/709\/38\/clb\/ex\/eii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/hd\/ex\/eii Sfc\/709\/38\/hd\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Sfc\/709\/38\/hd\/ex\/eii Sfc\/709\/38\/hd\/ex\/eii (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 709 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 709 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tanker 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 3800 (3800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Gvw 7490. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 713 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ht Clb (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5600 (5600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5700 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Exii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 410 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407\/29 Bsiv Pickup Clb (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 410 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5700 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Hd (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 609 (6700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cab. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cng Dsd (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5550 (5550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Cab Cng (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Tt Clb (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hsd. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab Cng (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Exii (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hdlb Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 712 Ex. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex2 Hsd (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 410 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407. (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 13.7 Ft Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 810 Ex\/38 Crx Bsiv Hdlb (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 712 Ex. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Hdlb Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/34 Ex2 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407. (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 6950 (6950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 410 Ex. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Clb Gvw 4450 (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Tata 712 Truck (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Tt Clb. (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 410 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Cng Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Cab (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Tata 712 Truck (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex Cab (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407. (4450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 608 (6000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex Bs Iv Hdlb. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709\/38 Ex Hdlb (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng Gvw 5950. (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 613 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 713 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab Cng. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Ex Cab Cng (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 5600. (5600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Cab Cng. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Hsd (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407\/31 Ex Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Tt Cab (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Gvw 7250. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 407 (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Ex Hdlb (5300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 407 Cng (5560 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 Bsiv Gvw 7300 (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407\/38 Ex2 Clb (7300 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Sfc 709 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks 609 (6700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 712 Ex Cab And High Deck. (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 709 Ex2 (7490 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 613 (7500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex Hsd (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tata Trucks Lpt 407 Ex2 Cab. (7250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Ex (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Tipper (5800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Sk 407 Ex (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Lpk 407 Bsiv (6250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "Variant": "Tipper Sk 407 (6250 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Ecomet 912 (7500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Ecomet 912 (7500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Milk Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner Le (4720 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner 14ft Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Partner 4 Tyre 14ft Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Tanker Cargo 759 (7490 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Gvw 6700 (6700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hdlb Bsiv Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Gvw 6600 (6600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Mls Fsd 14 Ft Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 4 Tyre Hsd 3320mm Ls Bsiv (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 4 Tyre Hsd 2670mm Bsiv Ps (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6020 (6020 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hsd 3320mm Bsiv Gvw 6860 (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Cargo 709 (7350 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6700 (6700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Lx Fsd 11ft 6 Tyre (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls 14 Ft Hsd Gvw 6860 (6860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 6 Tyre 3955mm Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Mls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6600 (6600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner 6 Tyre Xls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Hsd Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "Variant": "Trucks Partner Ls Gvw 6700. (6700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10 59 Refrigerated Van (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Chassis (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And Chassis (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab And High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab With Aluminum Container Body With Wind Deflector (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab With Aluminum Container Body With Wind Deflector (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.50 E Cab High Side Deck (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Xp Hsd Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E 134 Cab And Chassis (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Rhd Cab And Chasis (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Hsd Cng Rhd. (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Xp Hsd Rhd (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Rhd Cab And Chasis (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E 134 Cab And Chassis (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab And High Side Deck (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab With Aluminum Container Body (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 E Cab With Aluminum Container Body (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.59 Xp Cng Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng Gb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "10.75 F Hsd Rhd Cng Gb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750. (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Canter Canter Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Dumper Placer Dumper Placer (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.59 Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.59 Refrigerated Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.75 Refrigerated Van (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher 10.75 Refrigerated Van (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Eicher Truck Pro 1075 F Hsd Bs3 Ngb (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Fuel Carrying Tanker Pro 1059 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Garbage Tipper Garbage Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Milk Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Null Eicher 10.59 Tipper (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Null Eicher 10.75 Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 10.59 C Hsd Bs3 Ngb (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1049 C Refrigerated Van (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1055 Refrigerator Van (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Pro 1059 Xp Refrigerated Van (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Rear Drop Tipper Rear Drop Tipper (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Tanker (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck Pro 1075 F Cbc Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck 10.50 E (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck 10.50 E (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Truck Pro 1059 Xp F Hsd Ngb Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59. (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1080 Xp (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E. (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Gvw 7200. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Cbc Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 Gvw 6250 (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 C Hsd (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Ngb 16ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 C (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 C Fsd Gvw 5950 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Fsd. (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.70 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1050 E Cbc. (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 E Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C Fsd Bsiv (5490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd Bs Iv (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Cbc Cng Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 11.10 Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Cng Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cbc Bsiv Cng (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 E Cbc Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Cbc (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 C Dsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp Hsd. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp E Hsd Gvw 7400 (7400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd 14 Ft (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd Cab And Chasis (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Rhd Cab And Chasis (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 10.59 Xp E Hsd Ngb 14ft (6250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cab And Chassis. (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng 14 Ft Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.60 (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Gvw 7450. (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 K Cbc (5490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59. (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1050 E Hsd (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Hsd Cng (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Gvw 7500 (7500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xp (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.50 (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd 16ft Gvw 7490 (7490 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xpl (7250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 6037 C Hsd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Hsd Cng Ngb 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp Hsd (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Cab And Chassis (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Hsd Ngb 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Hsd Cng Ngb 14ft. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.59 (5900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1049 C Fsd (4995 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 E (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 10.59 Xp E Hsd 14ft (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 E Hsd Cng 12 Ft Gvw 6450 (6450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1055 C. (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 11.10 Gvw 6750 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.70 (6750 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.75 F Dsd Rhd (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.55 C Fsd (5950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 H Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Eicher 10.50 (5400 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xp E Cbc 14ft (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 F Hsd Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1075 H Hsd Cng Gvw 7450 (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks 10.59 Xpl (7250 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Trucks Pro 1059 Xpe Cbc Cng Ngb 14ft. (7200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Water Tanker (7450 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "Variant": "Water Tanker Water Tanker (7450 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Matador F 307 (3510 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Matador F 307. (3510 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Excel 4 (5850 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Excel 4. (5850 GVW)"
 },
 {
  "Company": "Bajaj",
  "Variant": "Tempo Traveller Delivery Van (3510 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wt49es Tc Al C.body Premium Aluminium Cargo Body (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26stc Al Box Sartaj Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26tc Al Box Cosmo Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26stc Al Box Sartaj Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wt49es Tc Al C.body Premium Aluminium Cargo Body (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Aluminum Box Wv26tc Al Box Cosmo Aluminium Box (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Fes Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Prestige Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Fes Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Zt50tclwb Fes Prestige Drive Away Chassis With Foh (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Fes Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Fes Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Cosmo Cowl Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc Lwb Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Zt50tclwb Fes Prestige Drive Away Chassis With Foh (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Prestige Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Fes Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt50tc A Prestige Cowl Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Sartaj Cowl Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26s Tc D Sartaj Cowl Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Fes Prestige Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wt48tc D Fes Prestige Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Chassis Wv26tc-d Cosmo Cowl Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo Wv26tc-b Cosmo (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Cosmo Wv26tc-b Cosmo (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49es Tc B Dumpr Plc Premium Dumper Placer (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49tc Dp Prestige Dumper Truck (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt49es Tc Dp Premium Dumper Truck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Dumpers Wt48tc Dp Prestige Dumper Truck (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Delevery Van Wv26tc-b Del. Van Cosmo Delivery Van (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Delevery Van Wv26tc-b Del. Van Cosmo Delivery Van (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tca Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tclwb Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26stcd Fes Fl Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26stcd Fes Fl Sartaj Drive Away Chassis (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tca Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26tcd Fes Fl Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wt50tclwb Fes Fl Prestige Drive Away Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Economy Face Less Chassis Wv26tcd Fes Fl Cosmo Drive Away Chassis (5740 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu Truck Wv26s Tc-iii Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Isuzu Truck Wv26s Tc-iii Shd. (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49estc B Pto Premium Cabin And Chassis With (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Kutty Premium Wt49estc B Pto Premium Cabin And Chassis With (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Milk Tanker Swaraj 4wd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Elwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Pto Prestige Cabin And Chassis With Pto (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Fes Premium Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc B Premium Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Premium Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Premium Cowl Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49estc D Fes Premium Drive Away Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Pto Prestige Cabin And Chassis With Pto (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Prestige Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Lwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Lwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Elwb Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bdc Prestige Dual Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt48tc B Prestige Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49es Tc B Premium Cabin And Chassis (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc B Prestige Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Wt49tc Bdc Prestige Dual Cabin And Chassis (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Truck (6390 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Prestige Truck (6390 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Hg72 Wv26s-tc Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26stc A (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26sm Ng Cbc Cng. (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26s Ng (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26sm Gh Ng Smdc (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26 S (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv 26s Iv Gh Ng Smdc. (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26sm Ng 72 Smdc Cng (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck (6140 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Truck Wv26s Ng 14 Ft 3335mm Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Wv26sm Ng72 Refrigerator Van (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Sartaj Xm 14 Feet (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt50tc A D.van Prestige Delivery Van (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt48tc-d Del.van Prestige Delivery Van (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt48tc-d Del.van Prestige Delivery Van (6200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Standard Delevery Van Wt50tc A D.van Prestige Delivery Van (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Metro Zt54 Ng Shd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Metro Zt54 Ng Shd. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Truck Super (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Super Truck Super (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Supreme Truck Zt54es Tc. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Swaraj Truck T 3500 (6990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Swaraj Truck T 3500 (6990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Tipper Wt 49 Estc (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Prestige 2815 Steel High Deck Bs Iv Ps (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Shd Bs Iv Ps. (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs Bsiv 3335mm Cng Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Supreme 4240 Steel High Deck Lwb Bs Iv (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Cab (4990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs Bsiv 3335mm Cng Gvw 7250 (7250 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng A Elwb. (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Hsd (5200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng A Elwb (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Xm Shd Bs Iv (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Gs 14ft Bsiv 3335mm Gvw 7200 (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Wv26s Tc Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Zt54m Ng Iv Gh Shd (7490 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 59 Xm Cargo Box Bsiv (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Cab Gvw 5200 (5200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 5252 Xm Shd (5220 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj 59 Xm High Deck (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Wv26s Ng Shd 14 Ft Cng Gvw 5990 (5990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Prestige Xm 14ft 4x2 3335mm (6440 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Tc Shd (7200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "Variant": "Trucks Sartaj Hg 72 Xm Shd Bs Iv. (7200 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Excel 4 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Excel 4 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Excel Tanker Excel (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Tanker Excel (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Tidv 3350 Wb Bsiv Ps (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Fm 2.6 Cr 4020wb Dv Gvw 4150 (4150 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Delivery Van (3900 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Traveller Strong (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van Smart (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T2 4020 Wb Delivery Van (5550 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Shaktiman Td 2650 (5850 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van Cng (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Utility Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Td 2650 Delivery Van (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Delivery Van 3700 Wb Abs Ps (3810 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller T1 Td 3050 Wb Bs4 Fm2.6cr Ps Rfr (3650 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Strong (3510 GVW)"
 },
 {
  "Company": "Force",
  "Variant": "Traveller Traveller Strong (5850 GVW)"
 }
]
module.exports = {
    GCV4
  };