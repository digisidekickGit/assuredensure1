const {ObjectId} = require('mongodb')

const GST_ID_FOR_LEDGER = ObjectId("650419d07c3a3a80c6cb0434") 
const Duties_And_Tax = ObjectId("648ac8ca7df926cfdd2ddccb") 


module.exports = {
  GST_ID_FOR_LEDGER,
  Duties_And_Tax
}
