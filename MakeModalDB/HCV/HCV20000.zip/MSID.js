const MSID =[
 {
  "Option": "Mahindra And Mahindra 215 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 215 Di Yuvraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 215 Yuvraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 225 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 225 Jivo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 235 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 245 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 245 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 245 Orchard",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 255 Bhoomiputra Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 255 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 255 Di Power Plus",
  "FuelType": "Diesel",
  "Variant": "25 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 255 Di Yuvraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 255 Yuv",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Bhoomiputra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Nbp Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Obp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Power Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Dlx Lt",
  "FuelType": "Diesel",
  "Variant": "30 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Mkm Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 265 Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Bic",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Nbp Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "39 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Tu Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Di Yuvo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Eco",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Eco 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Eco Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Nbp Eco Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Ns",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Obp",
  "FuelType": "Diesel",
  "Variant": "39 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Sp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Tu",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Xp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 275 Xp Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di Nst Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di Sarpanch Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di Sarpanch Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 295 Di Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 3015 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 365 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 395 Di Bhoomiputra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 395 Di Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 395 Di Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 415 Di Nbp Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 415 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 415 Di Yuvo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 415 Nst Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 415 Yuvo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 445 Arjun",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 445 Di Arjun Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 445 Di Ps Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Bic",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Bhoomiputra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Bpe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Nbp Ps Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Nst Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Nstwl-oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Sarpanch Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Xp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Di Xp Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Xp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Xp Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 475 Yuvo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Arjun",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Arjun Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Arjun Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Arjun Ps Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Arjun Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Power Plus",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Power Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Di Ps Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 555 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Bic",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Bp Oib Power Stg",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Bhoomiputra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Bic Crpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Bpe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Mkm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Mkm Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Mkm Oib Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Nbp Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Nbp Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Nst Rotry Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Nstwl-oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Power Plus Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Di Sarpanch Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Nbp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Obp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Xp Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 575 Yuvo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Bic",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Dcps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Di Sarpanch",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Eco",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 585 Nst Ps",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di Bp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di Nst",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di Oib Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di Sar",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Di Sarpanch Turbo Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Tc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 595 Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Arjun",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Arjun Ce",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Arjun Crpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Arjun Rjc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Di Arjun Cg",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Di Arjun Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 605 Di Ce Ultra",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 655 Di 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 755 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 443",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 555 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 605",
  "FuelType": "Diesel",
  "Variant": "60 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 605 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 605 Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun 7575",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 605",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 605 Di I 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 605 Di I 4wd",
  "FuelType": "Diesel",
  "Variant": "WITH AC CABIN TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 605 Di I",
  "FuelType": "Diesel",
  "Variant": "57 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 605 Di I",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo 655 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Arjun Novo Ms 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra B 275 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra G 353",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra G 453 Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra G 453 Regular",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Jivo 225 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Jivo 245",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Jivo 245 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Jivo 245 Di Ps 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra M 245",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Mahindra 475",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Mahindra Yuvraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Mahindra-575 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Mg 405",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Novo 605 Di",
  "FuelType": "Diesel",
  "Variant": "57 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Novo 605 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Mahindra And Mahindra Shaan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 30",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 31 Orchard",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 35mx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 40",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Shaktimaan S 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 717",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 724",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 724 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 735 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 735 Fee",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 735 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 735 Xt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 742 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 744",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 744 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 834",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 841 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 843 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 855",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 960 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Swaraj 963fe Pswod",
  "FuelType": "Diesel",
  "Variant": "63 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Tr605 Di Ce Ult-oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Mahindra And Mahindra Ultra 555 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 265 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 265 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 275 Di Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 275 Di Ps Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 275 Di Ps Lt",
  "FuelType": "Diesel",
  "Variant": "35 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 415 Di Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 415 Di Ps Crpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 415 Di Ps Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 475 Di Ps Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 475 Di Ps Lt Crpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Di 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Di Ps Crpto",
  "FuelType": "Diesel",
  "Variant": "2WD TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Di Ps Crpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Di Ps Lt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra Yuvo 575 Ps",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Mahindra And Mahindra 5275",
  "FuelType": "Diesel"
 },
 {
  "Option": "Mahindra And Mahindra Trakstar",
  "FuelType": "Diesel",
  "Variant": "550"
 },
 {
  "Option": "Swaraj 717",
  "FuelType": "Diesel",
  "Variant": "15 HP TRACTOR"
 },
 {
  "Option": "Swaraj 717",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 722 Super",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 724 Fe Ord",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 724 Nt",
  "FuelType": "Diesel",
  "Variant": "26 HP TRACTOR"
 },
 {
  "Option": "Swaraj 724 Nt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 724 Xm Orc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 733 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Fe",
  "FuelType": "Diesel",
  "Variant": "39 HP TRACTOR"
 },
 {
  "Option": "Swaraj 735 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Fee",
  "FuelType": "Diesel",
  "Variant": "35 HP TRACTOR"
 },
 {
  "Option": "Swaraj 735 Fee",
  "FuelType": "Diesel",
  "Variant": "36 HP TRACTOR"
 },
 {
  "Option": "Swaraj 735 Fee",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Sd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Xt",
  "FuelType": "Diesel",
  "Variant": "40 HP TRACTOR"
 },
 {
  "Option": "Swaraj 735 Xt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Xt 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 735 Xt Ps",
  "FuelType": "Diesel",
  "Variant": "42 HP TRACTOR"
 },
 {
  "Option": "Swaraj 742",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 742 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 742 Fe",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Swaraj 742 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 742 Xt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Bx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Fe",
  "FuelType": "Diesel",
  "Variant": "48 HP TRACTOR"
 },
 {
  "Option": "Swaraj 744 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Fe Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Fe Txcps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Nsm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Nsm Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Osm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Osm Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Tx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Xm",
  "FuelType": "Diesel",
  "Variant": "44.25 HP TRACTOR"
 },
 {
  "Option": "Swaraj 744 Xm",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "Swaraj 744 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 744 Xt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 825 Xm",
  "FuelType": "Diesel",
  "Variant": "20 HP TRACTOR"
 },
 {
  "Option": "Swaraj 825 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Ef",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Lx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Xm",
  "FuelType": "Diesel",
  "Variant": "35 HP TRACTOR"
 },
 {
  "Option": "Swaraj 834 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Xm 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Xm Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 834 Xmr",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "Swaraj 841 Xm",
  "FuelType": "Diesel",
  "Variant": "42 HP TRACTOR"
 },
 {
  "Option": "Swaraj 843 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 843 Xm Lx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 844 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Fe",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "Swaraj 855 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Fe Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Gx Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Special",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Tubro",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Tx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 855 Tx Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 960 Fe",
  "FuelType": "Diesel",
  "Variant": "60 HP TRACTOR"
 },
 {
  "Option": "Swaraj 960 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 963",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj 963 Fe",
  "FuelType": "Diesel",
  "Variant": "60 HP TRACTOR"
 },
 {
  "Option": "Swaraj 963 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Pt 735",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Sawraj 724 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj 724 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj 744",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj 841 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj 855",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj 855 Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj Fe 744 Bxdc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj Tractor 735 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Swaraj Swaraj Tractor 855 Fe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 215 B",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 60 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 730 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 730 Di Ii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 732 Iii Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 740 Super",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 745 Iii Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited 750 Di Rx",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited 750 Iii Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Baagban Di 30",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 35 Ii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 35 Rx Cm Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 39 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 39 Rx Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 47 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 52 Rx Dc Oib Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Hp Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Iii Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Iii Dc Oib Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Iii Dc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Mm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Mm Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Ps Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 60 Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 734 Iii Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 734 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 740 Iii Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 740 Iii Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 745 Iii Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 745 Iii Dc Oib Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 745 Iii Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 745 Iii Sc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 745 Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 75 Dc Ps Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 75 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Ii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Ii Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Ii Dc Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Dc Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Dc Oib Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Sc Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Iii Sc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Ps Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 750 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di 755 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di Rx 750 Iii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Di-60 Dc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Rx 42 Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Rx 42 Ps Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Rx 47 Ps Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Rx 60 Iii Ps Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Solis 4215 E",
  "FuelType": "Diesel",
  "Variant": "43 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Solis 5015",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Solis 6024",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Solis Yanmar 4515",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 35 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 40 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 42 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 60 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 735",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 740",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 740 Iii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 740 Iii 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 745",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 745 Di",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 75 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "International Tractors Limited Sonalika 750 Di Iii",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 750 Di Iii 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika 750 Iii Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Bagmaan Di 30 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 20 Gt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 22 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 22 Gt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 26 Gt",
  "FuelType": "Diesel",
  "Variant": "26 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 26 Gt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 30",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 32 Rx",
  "FuelType": "Diesel",
  "Variant": "32 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35 Hdm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35 Hdm S1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35 Oib Power Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35 Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 35 Sm Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 42 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 450",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 47 Rx",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 47 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 47 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 47 Rx 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 47 Rx 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50",
  "FuelType": "Diesel",
  "Variant": "52 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50 Hdm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50 Iii Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50 Rx",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 50 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 55",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 55",
  "FuelType": "Diesel",
  "Variant": "58 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60 Rx",
  "FuelType": "Diesel",
  "Variant": "42 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60 Rx 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 60 Senior",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 730",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 730 Ii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 730 Iii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 732 Iii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 734",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 740",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 745 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 745 Iii Rx Power Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 750",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 750 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Di 760",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt 20",
  "FuelType": "Diesel",
  "Variant": "20 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt 20",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt 20 Di",
  "FuelType": "Diesel",
  "Variant": "17.5 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt 22",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt 28",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Gt Sc 540",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Itl 20",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M 39",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M 41 Di Si",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M 45",
  "FuelType": "Diesel",
  "Variant": "47 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M Plus 39",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M Plus 41",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika M M Super",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Mileage Master",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Mileage Master",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Mileage Master Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Mm 18",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Nt 30",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Nt 30 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Rx 35 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Rx 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Rx Di Mileage Master",
  "FuelType": "Diesel",
  "Variant": "SUPER TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Di 42",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 42",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 47",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 50 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Sikandar Rx 750 Iii",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Standard 335 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Tiger 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 60 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 60 Rx 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 75 Rx 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Worldtrac 90 Rx 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "International Tractors Limited Sonalika Wt 75 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Escorts Limited 325 Jawan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 335 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 430 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 435 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 439 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 940 Tc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited 950 Tc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Adico Steel Track",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Es- 439",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escort 325",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escort 439",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts 340",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts 355",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts Farmtrac 30 Hero",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts Farmtrac 35 Champion",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts Farmtrac 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Escorts Farmtrac 60 Deluxe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Euro 42 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Euro 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Euro 45 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited F 15",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farm Trac 42",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtac Champion 39",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtac Champion 39",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 34",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 35 Champion",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 37 Champion",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 39",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 4x4",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Classic Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Classic Valuemaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Db",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Dbt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Dlt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Pro Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Smart Valuemaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 45 Um 4wd Ultramaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 50 Db",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 50 Epi",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Classic Epi Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dbt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dc Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Deluxe",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dx Joshila",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Dx Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Epi Pro Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Oib Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 60 Super Maxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6045 Executive Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 604s Sm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6050 Executive Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6050 Executive Ultramaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6050 Executive Ultramaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 Classic Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 Classic T20 Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 F2",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 F4",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 F5",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 F9",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 Pro",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6055 Pro Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6060",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6065",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6065 Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6065 Ultramaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 6075 Executive Ultramaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 65 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 70",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac 70",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Escorts Limited Farmtrac Atom 22",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Atom 26",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion 35 Valuemaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion 44 Smx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion F2",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion F2 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion Xp 41",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Champion Xp 41 Supermaxx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrac Ft65",
  "FuelType": "Diesel",
  "Variant": "55 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrack 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtrack 45 Dv",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Farmtract 35",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Ford 3000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Ft 26",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Ft 38",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Ft 40 Vmx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 430",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Ds Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Plus Lm 12.4",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Plus Lm 13.6",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Plus Lm Ps 13.6",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Vm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 434 Vmx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 435",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 437",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 437 Lm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 E1",
  "FuelType": "Diesel",
  "Variant": "41 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Plus Lm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Plus Lmps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Plus Sm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Ptt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Super Saver",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Xl",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 439 Xl Ss",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 440",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 440 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 442 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 445",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 445 Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 445 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 4455",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 4455",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Escorts Limited Powertrac 455",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac 7445",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Alt 3500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Alt 4000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Alt 4000 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 41 Plus",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 41 Plus Lm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 41 Plus Smps Mrpto",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 42 Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 445 Plus",
  "FuelType": "Diesel",
  "Variant": "47 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 47",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Lm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Lmps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Sm Ms",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Smps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Smps (Roi) Fa",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 50 Smps Fa",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 60 Full Euro",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Euro 60 Semi Euro",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Pt 425 N",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Pt 434 Ds+ Hr",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Pt 439 Ds+ Hr",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Steeltrac",
  "FuelType": "Diesel",
  "Variant": "15 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Powertrac Steeltrac",
  "FuelType": "Diesel",
  "Variant": "18 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Pt 3600",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Pt 434 Xl",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Pt 4455 Dc Sb Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Steel Tractor",
  "FuelType": "Diesel",
  "Variant": "15 HP TRACTOR"
 },
 {
  "Option": "Escorts Limited Steel Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Steeltrac 18",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Escorts Limited Tt 445 L 45hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "P M Diesels Pvt Ltd Shridev",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 241 Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 242 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 242 Xtrac",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 271 Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 2750 J Kuber",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 30 Di J Db",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 330 Sc Wdb Sl12",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 333 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 364 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 368 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 368 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 380 Wc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 485 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 5245 Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 5245 Pd Power Steering",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited 5245 Sarja",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 242",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 312",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 333",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 364",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 368 Hyd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 368 Sil",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 380",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 480",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 485",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 560",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 566",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher 6100",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Eicher Di 5660",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Gajraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Imt 533 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1030 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1030 Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1033",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di Dost",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di J Mahashakti With Disc Brake",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di J Mahashakti With Disc Brake Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di J Mahashakti With Sddb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di Mahashakti V1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di Mahashakti V1 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di Sddb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di V1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di-j-haluage",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Di-r",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Dij Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Dost",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 1035 Std",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 135 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 18 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Ag.tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di",
  "FuelType": "Diesel",
  "Variant": "36.5 HP TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di J Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di Planetary Drive",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di Planetary Plus V1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di-pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Di-pm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Eagle",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Hi Lift",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 241 Sarja",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 Di 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 Di J Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 Di Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 Di-j",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 245 J",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 250 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 250 Di Mahashakti",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 2635",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 30 Di-j",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 35 Di J",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 4410 Samrat",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 4410 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5241",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5245 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5245 Di 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5245 Di Maha Mahan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5245 Mahaan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 5245 Planatary",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 6028",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 6028 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 7250",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 7250",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 7250 Di V1 1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 8775 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 9000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 9000 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 9500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 9500 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Mf 9500 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Ngt 45 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Orchard Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 241",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 25",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 25 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 2750 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 2750 Kuber",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di Heavy Duyty With Sddb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di J",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di J Heavy Duty",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di Nayak",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Di Sddb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30 Orchard Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 30-j-std",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 364",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 368",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 4410 Samrat",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 5900 Di Gajraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe 5900 Gajraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe Mf 241 Di J Series",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Tafe Motors And Tractors Limited Tafe-30-j-haulage",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 3028 En 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 3028 En 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 3036",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 3036 En 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5005",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5036 C",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5036 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5036 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5036 D 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5038 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5038 D Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5039 C",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5039 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5039 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5041 C",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5041 Ps Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5042 C",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5042 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5042 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5042 D 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5042 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5045",
  "FuelType": "Diesel",
  "Variant": "63 HP TRACTOR"
 },
 {
  "Option": "John Deere 5045 D",
  "FuelType": "Diesel",
  "Variant": "47 HP TRACTOR"
 },
 {
  "Option": "John Deere 5045 D",
  "FuelType": "Diesel",
  "Variant": "63 HP TRACTOR"
 },
 {
  "Option": "John Deere 5045 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5045 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5045 D 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5045 D 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH ROTAVATOR"
 },
 {
  "Option": "John Deere 5050",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 D",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "John Deere 5050 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 D 16 9",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 D 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5050 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5055",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5055",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5055 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5055 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5055 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5060 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5060 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5060 E Pr 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5065 E 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5065 E Pr 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5075 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5075 E 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5104 Hs 104",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5104 Ms 14",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5104 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5105",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5105 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5105 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5105 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5204 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5205",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5210",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5210 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5210 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5305",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5310 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5310 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5310 E 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 E 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 E Creeper",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 E Creeper",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH DOZER"
 },
 {
  "Option": "John Deere 5310 I-96",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 Mfwd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310 Mfwd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "John Deere 5310 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310-e E-ms-81",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5310s",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5405",
  "FuelType": "Diesel",
  "Variant": "63 HP TRACTOR"
 },
 {
  "Option": "John Deere 5405 D",
  "FuelType": "Diesel",
  "Variant": "63 HP TRACTOR"
 },
 {
  "Option": "John Deere 5405 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 5410 Ts",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere 6120 B",
  "FuelType": "Diesel",
  "Variant": "120 HP TRACTOR"
 },
 {
  "Option": "John Deere Jd 5036",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere Jd 5045",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere Jd 5203",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere Jd 5310",
  "FuelType": "Diesel",
  "Variant": "FRONT END LOADER"
 },
 {
  "Option": "John Deere Jd 5310",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "John Deere Jd 5310",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Eicher Motors 241 Rda",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 241 Xm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 242 Holer",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 242 Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 242 R",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 242 Xtrac",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 312",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 333 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 333 Super Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 364 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 364 Sdi Ricardo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 368",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 368 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 368 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 368 Sdi Ricardo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 380 Hm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 380 Sc Super Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 480 Sdi Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 485 Sdi Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 485 Ss Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Eicher Motors 5150 Wc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 548 Hm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 557 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors 650 Sdi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 241",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 241 Xtrac",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 300",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 330",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 333",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 333 Plus",
  "FuelType": "Diesel",
  "Variant": "36 HP TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 364",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 380",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 380 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 480 Power Stg",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 485",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 485 Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 485 Power Stg",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 495",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 5150",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 548",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 548",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Eicher Motors Eicher 551",
  "FuelType": "Diesel",
  "Variant": "50 HP TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 551",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 557",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eicher Motors Eicher 557",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Eicher Motors Eicher 5660",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3030 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3032",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3032 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3032 Nx Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3037",
  "FuelType": "Diesel",
  "Variant": "39 HP TRACTOR"
 },
 {
  "Option": "New Holland 3037",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3037 Agricultural Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3037 Nx Plus Ps",
  "FuelType": "Diesel",
  "Variant": "39 HP TRACTOR"
 },
 {
  "Option": "New Holland 3037 Nx Plus Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3037 Tx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3130 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3230",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3230 Hx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3230 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3230 Nx 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3230 Power Stering",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3510 Ndl",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3600 -2 Ar (8x2)",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3600 Tx Heritage Edtn",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3600-2 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3600-2 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3600-2 Tx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Dlx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Ms",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Nx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Tx Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Tx Plus Spe Edd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Tx Spl Edtn",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Tx Super",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 3630 Tx Turbo",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 4010 Ndl",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 4510 Ndl",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 4510 Tt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 4710 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 4710 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 4710 4wd",
  "FuelType": "Diesel",
  "Variant": "47 HP TRACTOR"
 },
 {
  "Option": "New Holland 4710 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 5050 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 5500 Tt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 5500 Tractor Loader",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 5630 4wd",
  "FuelType": "Diesel",
  "Variant": "75 HP TRACTOR"
 },
 {
  "Option": "New Holland 6010 4wd",
  "FuelType": "Diesel",
  "Variant": "60 HP TRACTOR"
 },
 {
  "Option": "New Holland 6510 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 7510 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 7510 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland 8010 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland 9010 Dc Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Ford 3032",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3030",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3032",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3130",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3230",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3510",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3600-2",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 3600-2",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "New Holland Nh 3630",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 4010",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 4510",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 4510 Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 4710",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 5500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 5500 Tt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 5630",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 6010",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 6010 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 6500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 7500",
  "FuelType": "Diesel",
  "Variant": "75 HP TRACTOR"
 },
 {
  "Option": "New Holland Nh 7500 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Nh 7880",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "New Holland Tt 7500 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota 4501",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota A211n",
  "FuelType": "Diesel",
  "Variant": "21 HP TRACTOR"
 },
 {
  "Option": "Kubota A211n",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota A211n Bt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota B 2420",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota B 2441",
  "FuelType": "Diesel",
  "Variant": "24 HP TRACTOR"
 },
 {
  "Option": "Kubota B 2441",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota B 2741",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Kubota Agricultural",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota L 3408",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota L 4506 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota L 4508 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota L 4508 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Mu 4501",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Kubota Mu 4501",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Mu 4501 4wd",
  "FuelType": "Diesel",
  "Variant": "45 HP TRACTOR"
 },
 {
  "Option": "Kubota Mu 4501 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Mu 5501",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Kubota Mu 5501 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Nspu 68c Rice Transplanter",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Kubota Se 4549",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 17hp 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 18hp 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 225 App",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 22hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 22hp Bt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 22hp Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 270 A M",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 270 Viraat",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 27hp Nt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 27hp Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti Mt180",
  "FuelType": "Diesel",
  "Variant": "18.5 HP TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti Vt 224 1d",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mitsubishi Shakti Vt 224 1d 4wd",
  "FuelType": "Diesel",
  "Variant": "22 HP TRACTOR"
 },
 {
  "Option": "Vst Tillers Mt 180 D With Rotary",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mt 180\/jai 2w With Rotary",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mt 224 1d Ajai 4wd",
  "FuelType": "Diesel",
  "Variant": "22 HP TRACTOR"
 },
 {
  "Option": "Vst Tillers Mt 224-1d\/jai Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Mt 224-1d\/jai Plus 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti 9045 Di Viraaj Xt Dcps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 170 2w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 170 Di Samraat",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 171 Di Samraat",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 180 4w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 180\/jai 2w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 180d",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Shakti Mt 270 Viraat 4w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Vst 130 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Vt 180d Hs Jai 4w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Vst Tillers Vt 224 1di Ajai 4w",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace 450x Di Dc Oib",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace 854 Ng",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Ace Di 350 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Ace Di 550 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Di 350 Ng",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Di 450 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Di 6565 Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ace Dl 350 Sc Ng",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr 3035 E",
  "FuelType": "Diesel",
  "Variant": "35 HP TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr 3035 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr 3040 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr 3042 E",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 45 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 45e",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 50 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 50 Dcps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 55 4wd Ac",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 60",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 70 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 80 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agrolux 80 Profiline",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agromaxx 45 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Agromaxx 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Same 393",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Same 453",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Same 503",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Same Deutz Fahr Same 603",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson 241 D",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson 241 D1",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson 241 Eagle",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson 241 Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Di (H.p.) Diesel Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Di - Idb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Di J Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Dj J Mahashakti Dcb",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Dj J Mahashakti Idb Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1035 Dj J Mahashakti Idb Sc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 1134 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Di J Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Di Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Di Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Mahashakti Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Mahashakti Pm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Oib Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Pd Dc",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 241 Pm",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 245 Dj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5118",
  "FuelType": "Diesel",
  "Variant": "MINI TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Di Maha Mahan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Di Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Mahaan",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Planetary Drive",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Sarja Dc Oib Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 5245 Sarja Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 6028",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 7250 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 9000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 9000 Oib Pd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 9500",
  "FuelType": "Diesel",
  "Variant": "58 HP TRACTOR"
 },
 {
  "Option": "Massey Ferguson Mf 9500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 25",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 2750 Kuber",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 30 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 30 Di Orchid Plus",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 30 Hd Mahashakti",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 5900 Gajraj",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 5900 Gajraj Tnp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 7250 Power Up",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe 7250 Power Upp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Massey Ferguson Tafe Mf 7250 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Abhiman",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 300",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 400",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 400 Hbt",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 450",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 450 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan 500",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Balwan Di 330 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Ox 25",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Ox 25 Orchard",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Ox 45",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Sanman 5000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Force Motors Sanman 6000",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 2522 Edi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 2522 Fx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 3522 Coastal",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 3522 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 3522 Edi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 4922 Edi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 5022 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt 5022 Rx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hm 4511",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hm 5911",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 2511",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 2522",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 2522",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH DOZER"
 },
 {
  "Option": "Hmt Hmt 2522 Edi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 2522 Orchard",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 3511",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 3522",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 3522 Dx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 3522 Edi",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 4922",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 5022",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 5911",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Hmt Hmt 6522",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt 6522",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Hmt Hmt 7511",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt-3022",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Hmt Hmt3522fx",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5103-40hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5203 S 50hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5203-47hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5310 55hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5310 S 70hp",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Larsen And Toubro 5802",
  "FuelType": "Diesel",
  "Variant": "TRACTOR WITH LOADER"
 },
 {
  "Option": "Agri King Tractors Agri King 20-55",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors 280 Dx 2wd Ps Ob",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 120 Mini Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 200",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 200 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 200 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 200 4wd Ps",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 200 Mini Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 250",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 250 2wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 250 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 250 4wd Ps Ob",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 250 Mini Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 2600 Mini Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 280 4wd",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Captain Tractors Di 280 Mini Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "D K Diesels Pvt Ltd D K Champion 165di",
  "FuelType": "Diesel",
  "Variant": "MINI TRACTOR"
 },
 {
  "Option": "D K Diesels Pvt Ltd D K Champion 165di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "D K Diesels Pvt Ltd D K Champion 240di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Eisuke Super Delux",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Farmer Tractor Farmer Di 1200",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Field Marshal Fm 625 Di",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ford 3630 Tractor",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Ford Ford 3610",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Gromax Trakstar 531",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Gromax Trakstar 531",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Gromax Trakstar 550",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 },
 {
  "Option": "Gromax 50",
  "FuelType": "Diesel",
  "Variant": "TRACTOR"
 }
]

module.exports = {
    MSID
  };