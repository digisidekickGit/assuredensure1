const mongoose = require("mongoose");

const PolicySchema = new mongoose.Schema(
  {
    PolicyType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PolicyType",
      required: [true, "PolicyType is required"],
    },
    POS: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Pos",
      required: [true, "Pos is required"],
    },
    InsuranceCompany: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "InsuranceCompany",
      required: true,
    },
    InsuranceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "InsuranceType",
      required: true,
    }, // CATEGORY*
    InsuranceUnderFlow: {
      type: [mongoose.Schema.Types.ObjectId],
      ref: "InsuranceType",
      // required: true,
    },
    PolicyNumber: {
      type: String,
      unique: true,
      required: true,
    },
    InsureeName: {
      type: String,
      required: true,
    },
    RSD: {
      type: String,
      required: true,
    },
    RegistrationDate: {
      type: String,
    },
    Commission: {
      type: Object,
    },
    Status: {
      type: String,
      enum: ["PENDING", "APPROVED", "REJECTED", "HOLD"],
      default: "PENDING",
    },
    IMTType: {
      type: String,
      enum: ["NONE", "IMT 23", "IMT 34"],
      default: "NONE",
      // required: true,
    },
    FuelType: {
      type: String,
      // enum: ["NONE", "PETROL", "DIESEL", "PETROL + CNG", "EV"],
      default: "NONE",
    },
    BusinessType: {
      type: String,
      enum: ["NEW", "USED", "RoleOver + Renewable"],
      default: "USED",
      required: true,
    },
    VehicleNumber: {
      type: String,
      required: true,
      validate: [
        {
          validator: async function (v) {
            if (v.length < 4) {
              return false;
            }
          },
          message: (props) =>
            `${props.value} It should Greater then 4 Characters`,
        },
        {
          validator: async function (v) {
            if (v.length === 4) {
              const REGEXfOR4 = /^[A-Z]{2}[0-9]{1,2}$/;
              return REGEXfOR4.test(v);
            }
          },
          message: (props) => `${props.value} It is not a valid vehicle Number`,
        },
        {
          validator: async function (v) {
            if (v.length === 4) {
              return true;
            } else {
              const VehicleValidatorRegex =
                /^[A-Z]{2}[0-9]{1,2}([A-Z])([A-Z]*)[0-9]{4}$/;
              return VehicleValidatorRegex.test(v);
            }
          },
          message: (props) => `${props.value} It is not a valid vehicle Number`,
        },
        {
          validator: async function (v) {
            if (v.length === 4) {
              return true;
            }
            const count = await mongoose.models.Policy.countDocuments({
              VehicleNumber: v,
            });
            return count === 0;
          },
          message: (props) =>
            `${props.value} is not a valid It should  unique.`,
        },
      ],
    },
    RTO: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "RtoGroupChecker",
    },
    YearOfManufacture: {
      type: String,
      required: true,
    },
    PaymentMode: {
      TypeOfPaymentMode: {
        type: String,
        required: true,
      },
      paidBy: {
        type: String,
      },
      receivedBy: {
        type: String,
      },
    }, // key => TypeOfPaymentMode:[Online,PartPayment,Credit,Cheque] , paidBy,receivedBy,
    IssueDate: {
      type: String,
      required: true,
    },
    ODPremium: {
      type: String,
      required: true,
    },
    ODPremiumGST: {
      type: String,
      //   required: true,
    },
    TPPremium: {
      type: String,
    },
    TPPremiumGST: {
      type: String,
    },
    LLPAPremium: {
      type: String,
    },
    LLPAPremiumGST: {
      type: String,
    },
    GrossPremium: {
      type: String,
    },
    NETPremium: {
      type: String,
    },
    NewPolicyCopy: {
      type: String,
      required: true,
    },
    RC1: {
      type: String,
    },
    RC2: {
      type: String,
    },
    PreviousPolicy1: {
      type: String,
    },
    PreviousPolicy2: {
      type: String,
    },
    Branch: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Branch",
    },
    NCB: {
      type: Number,
      enum: [0, 20, 25, 35, 45, 50],
      default: 0,
    },
    Remark: {
      type: String,
    },
    GetAmount: {
      type: Number,
      default: 0,
      // ref: "Bank",
      // required: true,
    },
    ReceivedBank: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bank",
      // required: true,
    },
    PaidBank: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bank",
      // required: true,
    },
    MakeModal: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "MakeModal",
    },
    Variant: {
      type: String,
    },
    // Purchase: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "Purchase",
    // },
    // PurchaseReturn: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "Purchase",
    // },
    isPurchase: {
      type: Boolean,
      default: false,
    },
    BasedOn: {
      type: String,
    },
    Broker: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Broker",
    },
    // RM: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "Employee",
    // },
    EnteredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
    },
    ApprovedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
    },
  },
  { timestamps: true }
);

// PolicySchema.pre('save', function (next) {
//   if (this.isModified('VehicleNumber')) {
//     this.VehicleNumber = this.VehicleNumber.toUpperCase();
//   }
//   next();
// });

module.exports = mongoose.model("Policy", PolicySchema);
