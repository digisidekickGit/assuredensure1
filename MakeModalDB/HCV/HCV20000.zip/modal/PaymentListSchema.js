const mongoose = require("mongoose");
const PaymentListSchema = new mongoose.Schema(
  {
    EntryDate: {
      type: String,
      // required: true,
    },
    CashBankAccount: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bank",
      // required: true,
    },
    Remark: {
      type: String,
      // required: true,
    },
    voucherType: {
      type: String,
      default:"Payment"
      // required: true,
    },
    PaymentList: [
      {
        PartyAccount: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Pos",
        },
        Account: {
          type: Number,
        },
        RefNumber: {
          type: String,
        },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("PaymentList", PaymentListSchema);
// {
//     PartyAccount: PartyAccountData._id,
//     Account: Number(Account),
//     RefNumber,
//     Name: PartyAccountData.Name,
//   }
