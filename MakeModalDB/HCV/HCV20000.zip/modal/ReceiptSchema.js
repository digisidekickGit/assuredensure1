const mongoose = require("mongoose");
const ReceiptSchema = new mongoose.Schema(
  {
    EntryDate: {
      type: String,
      // required: true,
    },
    CashBankAccount: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Bank",
      // required: true,
    },
    Remark: {
      type: String,
      // required: true,
    },
    voucherType: {
      type: String,
      default: "Receipt",
      // required: true,
    },
    Receipt: [
      {
        PartyAccount: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Pos",
        },
        Account: {
          type: Number,
        },
        RefNumber: {
          type: String,
        },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Receipt", ReceiptSchema);
// {
//     PartyAccount: PartyAccountData._id,
//     Account: Number(Account),
//     RefNumber,
//     Name: PartyAccountData.Name,
//   }
