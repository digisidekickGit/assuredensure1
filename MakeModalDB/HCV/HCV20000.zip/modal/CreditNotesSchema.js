const mongoose = require("mongoose");
const CreditNoteSchema = new mongoose.Schema(
  {
    EntryDate: {
      type: String,
      // required: true,
    },
    PartyAccountLedger: {
      type: mongoose.Schema.Types.ObjectId,
    },
    Remark: {
      type: String,
      // required: true,
    },
    voucherType: {
      type: String,
      default: "CreditNotes",
      // required: true,
    },
    CreditNotes: [
      {
        PartyAccount: {
          type: mongoose.Schema.Types.ObjectId,
        },
        Account: {
          type: Number,
        },
        RefNumber: {
          type: String,
        },
        key: {
          type: String,
        },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("CreditNote", CreditNoteSchema);

