const mongoose = require("mongoose");

const PayoutGridSchema = new mongoose.Schema(
  {
    InsuranceType: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "InsuranceType",
        required: true,
      },
    ],
    InsuranceCompany: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "InsuranceCompany",
    },
    Broker: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Broker",
    },
    PolicyType: [{ type: mongoose.Schema.Types.ObjectId, ref: "PolicyType" }],
    RTOGroup: [
      { type: mongoose.Schema.Types.ObjectId, ref: "RtoGroupChecker" },
    ],
    // Manufacturer: [
    //   { type: mongoose.Schema.Types.ObjectId, ref: "Manufacturer" },
    // ],
    MakeModal: [{ type: mongoose.Schema.Types.ObjectId, ref: "MakeModal" }],
    PA: {
      type: String,
      required: true,
    },
    // VehicleModal: [
    //   { type: mongoose.Schema.Types.ObjectId, ref: "VehicleModal" },
    // ],
    BasedOn: {
      type: String,
      required: true,
    },
    NCBSTATUS: {
      type: String,
      default: "Yes",
      enum: ["Yes", "No"],
    }, // ["Yes","No"]
    IMTType: {
      type: String,
      enum: ["NONE", "IMT 23", "IMT 34"],
      default: "NONE",
      // required: true,
    },
    FuelType: {
      type: String,
      default: "NONE",
    },
    AddDetails: {
      type: [Object],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("PayoutGrid", PayoutGridSchema);
