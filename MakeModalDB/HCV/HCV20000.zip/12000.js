const HCV2   = [
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 10.95 Gvw 12000 (12000 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 10.95 Gvw 12000 (12000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Sa 1212 Tc (12180 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Sa 1212 Tc (12180 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sak 1212 (12180 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 12200 (12200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 12200 (12200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Trucks Zt 54 Sm (12250 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker Lpt 1109 Gvw 12500 (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex 2 (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt1109ex2 (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt1109ex2. (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex. (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex. (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt1109ex2 (12500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex 2 (12500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 10.90 Gvw 12500 (12500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 10.90 Gvw 12500 (12500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 12500 (12500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 12500 (12500 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Isuzu Truck Is 12te Iii (12565 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "1214 R Refrigerator Van (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R E 4x2 Chs. (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Chs. (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Hsd Gvw 12800 (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R E 4x2 Chs 4800 E4 (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Chs (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Gvw 12800 (12800 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Fsd Gvw 12800 (12800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 He X2 (12900 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 He X2 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Ecomet 1212 Refrigerator Van (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Furnace Oil Tanker Ecomet 1212 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ecomet 1212 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1212 2850 Mm (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Wider Hsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le Cabin Chassis. (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1213 Ls 20ft Hsd (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Lx 3900wb H4 95kw Crs Ac Cab Fsd (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Wider Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Cabin Chassis (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1213 Lx 22ft Cabin Chassis (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1112 Gvw 12900 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 - 3970 Mm Wb Day Cab (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Wider Hsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Strong Hsd (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1212 3970 Mm Wb Day Cab (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Wider Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1113 Lx 95crs (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1212 4750 Mm Wb Day Cab (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Hsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1212 4200 Mm Wb Day Cab (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Wider Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212. (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Smart Hsd (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1213 Lx 22ft Hsd (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Cabin Chassis (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 4200mm Strong Hsd Gvw 12900 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Wider Hsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 - 2850 Mm Wb Day Cab (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 - 4750 Mm Wb (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 - 4200 Mm Wb (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Wider Fsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 17 Ft Wider Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Wider Dsd Body (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212. (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1213 Lx 4500wb (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 20 Ft Cabin Chassis (12900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1212 Le 22 Ft Hsd Body (12900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 Xp Gvw 12900 (12900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 (12950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 Xp. (12950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 Xp (12950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 (12950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 Xp (12950 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1211 (12976 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1211 Hsd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Milk Tanker Pro 1110xp (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 1110xp H Refrigerated Van (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 1110xp L Cbc 22ft Refrigerated Van (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 1110xp Refrigerated Van (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck Eicher 11.10 Xp Container (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd 20ft Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Xp H Hsd. (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Xp H Hsd Rhd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Xp (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp G Hsd Rhd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd 19ft Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp L Cbc. (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3013 H. (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Cbc (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Xp (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Cbc (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3013 H (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp L Hsd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10xp G (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3013 H Hsd Rhd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.12 Xp L (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.12 Xp L. (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 G (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd Rhd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.12 Xp (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp G Hsd 17 Ft Bsivng Ngb (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Cbc 20ft Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.12 Xp (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Xp Hsd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp G Cbc Gvw 12976 (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd (12976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Ms Container Ps Ngb 20ft (12976 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 Gvw 12979 (12979 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt 1109 Hex2 Refrigerator Van (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt 1109 Refrigerator Van (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt 1109\/42 Hex2 19 Ft Refrigerator Van (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt\/1109\/42\/h\/exii Lpt\/1109\/42\/h\/exii (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt\/1109\/42\/h\/exii Lpt\/1109\/42\/h\/exii (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker Lpt 1412 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker Lpt 1109 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 H Ex2 Hsd (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1412 Crx Hdlb (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 He X2 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1010\/38 Bsiv Cab (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1412 Crx Hdlb. (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 H Ex2 Gvw 12990. (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1412 Crx Hdlb Container Body (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1010 Crx Hd. (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1010 Crx Hd (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 H Ex2 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 He X2 Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 11.10 H Cab & Hsd High Side Deck 19 Ft (12990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Super 12.9 Xm (12990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Trucks Zt54 S Xm Gvw 12990 (12990 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Trucks Super 12.9 Bsiv 3940 Mm (12990 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Pro 1110xp T Gvw 13000 (13000 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Tip Trailer 1217c 4x2 (13000 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Tipper 1217c (13000 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1217c 4x2 Cbc Gvw 13000 (13000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 20r Cbc (13100 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 20ft Cbc. (13100 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 20ft Hsd Gvw 13100 (13100 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 E4 (13100 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Guru 1111 22ft Cbc (13100 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 E Cbc Rhd (13200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 E Cbc Rhd (13200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13200 (13200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13200 (13200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 13500 (13500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 13500 (13500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13500 (13500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13500 (13500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Gvw 13600 (13600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Smart Hsd Gvw 13600 (13600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Smart Hsd Gvw 13600. (13600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ecomet 1212 T 7 Cum Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Hsd 22ft Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1212 Smart Cbc Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Smart Hsd Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Strong Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Strong Container Body Gvw 13800. (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1212 Cbc Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Strong Hsd Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13800 (13800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1412\/45 Hdlb Gvw 13850 (13850 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1412\/42 Hdlb Gvw 13850 (13850 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1412\/45 Hdlb Gvw 13850. (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 M Slp Hsd 22ft (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 J Slp Hsd 20ft (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 J Cbc (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 H Bsiv. (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 Hsd 19ft (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 J Cbc 24ft (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3014 H Slp Hsd 19ft (13850 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck Eicher 11.10 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck 11.10 Gvw 13950 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck 11.10 Gvw 13950 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck Eicher 11.10 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 15.16 Gvw 13950. (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 15.16 Gvw 13950 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 15.16 Gvw 13950 (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13950. (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 15.16 Gvw 13950. (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13950. (13950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13976 (13976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd Gvw 13976 (13976 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 13976 (13976 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 13990 (13990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 13990 (13990 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Bs Iii (13990 GVW)"
 },
 {
  "Company": "Mahindra",
  "MakeModel": "Trucks Furio 14 4x2 20ft Cbc (14000 GVW)"
 },
 {
  "Company": "Mahindra",
  "MakeModel": "Trucks Furio 14 4x2 19ft Hsd (14000 GVW)"
 },
 {
  "Company": "Mahindra",
  "MakeModel": "Trucks Furio 14 4x2 24ft Cbc (14000 GVW)"
 },
 {
  "Company": "Mahindra",
  "MakeModel": "Trucks Furio 14 4x2 22ft Cbc (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Al 1413 Refrigerator Van (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1413 Ls 20ft Wider Hsd Body (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1412 Le 20 Ft Hsd Body (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1413 Ls 17ft Cbc (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1413 Ls 22ft Hsd (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1413 Ls 17ft Hsd Body (14000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Boss 1413 Ls 20ft Wider Dsd Body (14000 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1414 R Cbc 22 Ft Gvw 14040 (14040 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1414r 4x2 4250wb Hsd (14040 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Truck Ecomet 1412 Strong 4750mm Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Smart Cbc Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1412 4750mm Smart Hsd. (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1412 Strong 4200mm Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1412 Strong 4200mm Gvw 14050. (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1412 4750mm Smart Hsd (14050 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110xp H Hsd 20ft Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1414r 4x2 3760wb Hsd Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1414r 4x2 4800wb Cbc Gvw 14050 (14050 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Gvw 14200 (14200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Gvw 14200 (14200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tdv Gvw 14375 (14375 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tdv Gvw 14375 (14375 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex2 (14500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Ex2 (14500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.10 Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.14 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.14 H. (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 11.14 H Hsd Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 11.14 (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114 H Hsd. (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114 H Hsd (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 11.14xp H Hsd (14500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 11.10 Gvw 14500 (14500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Hsd (14600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4750 Mm Smart Hsd (14600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet1214 (14600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1214 4750 Mm (14600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1214 4200 Mm Wb Day Cab (14600 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214. (14600 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1510 (14860 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1510 (14860 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1109 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1109 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1518 (14900 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1518. (14900 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1518 (14900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1212 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 11.10 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 11.10 Gvw 14900 (14900 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 11.10 Gvw 14950 (14950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 11.10 Gvw 14950 (14950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Truck Pro 1110 Xp H Cbc Gvw 14950 (14950 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1110 Xp Gvw 14950 (14950 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Hd Gvw 14990 (14990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 14990 (14990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1109 Gvw 14990 (14990 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 3015 J Slp Cbc Bs3 20 Ft Abs (15184 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Hsd (15184 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 Hsd (15184 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Cbc (15184 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 (15184 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1512 Truck (15200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1512 Truck (15200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1112 Gvw 15200 (15200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1512 (15200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1512. (15200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Cheetah 1\/45 (15244 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Cheetah 1\/45 (15244 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 19ft Bs4ng Ngb (15360 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp L Cbc Gvw 15360 (15360 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 20ft Bs4ng Ngb (15360 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd (15360 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd. (15360 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp L Hsd 22ft Bs4ng Ngb (15360 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/54 (15430 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/54 (15430 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Ecomet 1214 Refrigerator Van (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1214 Hsd 22 Feet (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4750 Mm Smart Cbc (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Hsd Gvw 15500 (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Gvw 15500 (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Cbc Gvw 15500. (15500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Hsd Gvw 15500. (15500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Dumper Tdv (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker Se 1613 (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker Se 1613 (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1613 Gvw 15660 (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1510 Truck (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1613 Gvw 15660 (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1510 Truck (15660 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ct 1611 Comet Gvw 15660 (15660 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra Lpt 1518\/45 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Ecomet 1214 Refrigerator Van Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4750mm Hsd Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Fsd Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4200mm Smart Cbc Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Hsd Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 3015 J Slp Hsd Bs3 Ps Ngb (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Cbc 19 Ft (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 20ft Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Hsd Gvw 15700 (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 19ft Bs4ng Ngb 15700 Gvw (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 M Hsd Prm Bsiv 24ft (15700 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Hsd Gvw 15700. (15700 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/53 Bsiv 24 Ft Hdlb (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/45 Bsiv Hdlb (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Hdlb. (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra Lpt 1518 Hd (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Cbc. (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/45 Bsiv Hdlb. (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/49 Bsiv Hdlb Gvw 15710 (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/49 Cbc (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Hdlb (15710 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/49 Hdlb Gvw 15800 (15800 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Gvw 15860 (15860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Gvw 15860. (15860 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/54 Gvw 15875 (15875 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4750mm Smart Hsd Gvw 15910 (15910 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4750mm Hsd Gvw 15910 (15910 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 4200mm Smart Hsd Gvw 15910 (15910 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Milk Tanker Ecomet 1214 Cbc Smart (15990 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 5200mm Smart Hsd Gvw 15990 (15990 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615. (16000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 (16000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 (16000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1615 Tc (16000 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 M Cbc Prm Bsiv 24ft Gvw 16020. (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 M Hsd 24ft Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 20ft Bsiv Ngb Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 S Hsd 19ft Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 M Cbc Prm Bsiv 24ft Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Hsd Slp 20ft Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp L Hsd 22ft Bsiv Ngb Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Hsd Slp 19ft Gvw 16020 (16020 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 1114xp H Hsd 19ft Bsiv Ngb Gvw 16020 (16120 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/45 Hdlb Gvw 16190 (16190 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Hdlb Gvw 16190 (16190 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1616h 185 1616h (185\\) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1616h 185 1616h (185\\) (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Cab And Tipper Chassis With Taper Shaft Pto ( Tn Only) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 Hsd (175) 1611 Hsd (175) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 Hsd (175) 1611 Hsd (175) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612\/3 (185wb) 1612\/3 (185wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612\/3 (185wb) 1612\/3 (185wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612\/4 (210wb) 1612\/4 (210wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612\/4 (210wb) 1612\/4 (210wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 Cowl (170) 1611 Cowl (170) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 Cowl (170) 1611 Cowl (170) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612h (170.5wb) 1612h (170.5wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1612h (170.5wb) 1612h (170.5wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611\/3 Hsd (189) 1611\/3 Hsd (189) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611\/3 Hsd (189) 1611\/3 Hsd (189) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Ch (142) Bs - Ii (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Ch (115) Bs - Ii (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h\/1 (210wb) Cg1613h\/1 (210wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h\/1 (210wb) Cg1613h\/1 (210wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h\/2 (244wb) Cg1613h\/2 (244wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h\/2 (244wb) Cg1613h\/2 (244wb) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Fet (115) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Fbt (115) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Fbt (142) Bs - Ii (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Fet (142) Bs - Ii (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 D Cabin (175) 1611 D Cabin (175) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611 D Cabin (175) 1611 D Cabin (175) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1613h\/1 Sg (170.5) 1613h\/1 Sg (170.5) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1613h\/1 Sg (170.5) 1613h\/1 Sg (170.5) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611\/3 S Cabin (189) 1611\/3 S Cabin (189) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1611\/3 S Cabin (189) 1611\/3 S Cabin (189) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Rcb Fbt (115) (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Price (6x2) Ct 1613 Rcb Fbt (142) Bs - Ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Bitumen Tanker Se 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Bitumen Tanker Lpo 1512 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Bitumen Tanker Lpk 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Bitumen Tanker Sk 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Box Tipper Lpk 1615 Fcab (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Box Tipper Lpk 1616\/36 10 Cum (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Car Carrier Lpo 1610 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Car Carrier Lpt 1615 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Car Carrier Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Dumper 1612 Dumper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Dumper Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Edible Oil Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Edible Oil Tanker Lpt 1615 Cowl (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Fuel Carrying Tanker Se 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Fuel Carrying Tanker Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Furnace Oil Tanker Lpt 1612 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Furnace Oil Tanker Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt 1613 Refrigerator Van (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpta (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Maintenance Van Lpt 1613 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker Lpt 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Milk Tanker Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/48 Tc With P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Se 1613\/42 H.d. P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/52 Tc Cowl E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/48 Tcic P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpo 1512tc\/55 C.c. Ps E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/48 Tcic P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613tc\/62 Truck Chassis (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tc Cabin E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/52 Tc Cowl E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tc P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Se 1613\/42 H.d. P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/48 Tc With P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tcic P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tcic P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpo 1512tc\/55 C.c. Ps E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613tc\/62 Truck Chassis (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tc Cabin E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se & Lpt Trucks Lpt 1613\/42 Tc P.s. E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se 1613 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Se 1613 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1210 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1612 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1620 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1615 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1212 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker Lpt 1616\/42 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1615 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker Lpt 1613 Milk Van (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1510 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1510 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1620 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1210 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1612 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1212 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tanker Lpt 1616\/42 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 2213 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1612. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lp 1512 Tc. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1312 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1616 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1618 Crx Bsiv. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1612. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1312 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/45 Hdlb Gvw 16200. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1612 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1618 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1210 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tdv Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpo 1618 Chasis Only (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1210 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lp 1512 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1612 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpo 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tdv Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1613 Chasis Only (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1512. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1510 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Cowl (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Tc. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1613\/42 Cowl. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1618 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Se 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 2213 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Tc. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1616. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpo 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpo 1610 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1510 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpo 1610 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lp 1512 Tc Cowl (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1512. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Sk 1613 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1512 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1616 Truck. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518\/45 Hdlb Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1616 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Gvw 16200. (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Bsiv Cowl (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Hsd (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1213 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1109 Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Tata 1612 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Turbo (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1512 Truck (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks 1612 Tc (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tip Trailer Lpk 1618 Cre Bsiv (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613 Cr Cab Ac 10x2 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper 1612 Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1615 10cum Box Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Se 1613\/42 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpt 1510 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1613 8.5 Cum (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1618 10 Cum Bs Iv (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613\/36 Bs Iv 8.5 Cum Fe Box Body (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613 Cowl Tr (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Signa 1615 K Cr Bsiv (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Tata 1210 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper 1614 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1613 Tcic (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1618 Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1616 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613 8.5 Cum Box Body (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613\/697 Bs-iii Cab Sr (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Lpk 1613\/36 10cum. Box Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Lpk 1613\/36 (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Lpk 1618\/36 10cum. Box Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Sk 1613tc\/36 Cab S\/r E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Lpk 1613\/36 7cum. Box Tipper (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Sk1613\/36 Cowl W\/o Kit E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Sk1613\/36 Cowl Tr Box E-ii (16200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tippers Sk 1613\/36 Cab Box T Ram E-ii (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Al 1612 Car Carrier (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Al 1618 Refrigerator Van (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Car Carrier Al 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h Cg1613h (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Cg1613h Cg1613h (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Comet 1611\/3 - 4800 Mm Wb (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Comet 1611\/3 - 4800 Mm Wb (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Fuel Carrying Tanker 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Furnace Oil 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Milk Tanker Al 1616 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Pharma Chemical Tanker 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Stallion (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Stallion (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker Alco 1616 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker Comet 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker Comet 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1612 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1612 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tanker 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 4x2 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Sfc 1616 - 3810 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 Xp (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ct 1616 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1616 - 2920 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Alco 3\/10 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper St-1613h\/1 - 3810 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper U-3519 Tt (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1616 Sf 150wb Cowl (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Al 1612 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Al 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Fv1616 3600 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ct 1613\/1 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1616 Sf Cabin And 6.5 Cum (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Sfc 1616 Bs Iii 3810mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ct 1613\/2s (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Al 1616 Xl (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper U 1616 T (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Ct 1611 Comet (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Cargo 1614 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper U1618 3600 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 Sftg Cab Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Al 1616 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 8.5 Cum (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Al 1616 Xl Hd (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper Fv 1616\/1 - 3600 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1618 4x2 10.5 Cum (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tractor Trailer Al 1612 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Truck Cg1613h (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Xl (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 4x2 Haulage 4330mm Bsiv. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al Viking 4\/89. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1612 Il 4x2 Haulage (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Xl\/2 5334 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il\/1 4700 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1612 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1613 S (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 4\/186. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/1 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 Cowl Chassis 4x2 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks U 1619 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/2. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/51 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Xp\/1 4700 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1612 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 4330mm Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il 4330 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il\/4. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 4\/51 Gs (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1612 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/2c 4x2 Haulage 4700 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet Gold 1616 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet Gold 1616 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/106 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il\/4 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 4\/186 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet Super (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 4\/186 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6600mm Bsiv. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 4\/51 Gs (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1612 Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al Viking 4\/89. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al Viking 4\/89 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Xl \/3 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet 1611 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1613 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6250mm Bsiv. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Comet Super (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al Viking 4\/89 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 4x2 Haulage 4330mm Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Xl \/3 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alco 3\/10 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1613 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1612 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 4\/51 Viking (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Tusker Super (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/21 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il\/2 5334 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alco 3\/10 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Xp 4330 Mm (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6250mm Bsiv (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1613 H (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1612 Il (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Xl (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1613 S (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 4\/186. (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 4\/51 Viking (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Alpsv 4\/106 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "20.16 H Cbc Pto Lr Ps Set Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "20.16 H Cbc Pto Lr Ps Set Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 20.16 M Cbc Ps Lr Sft 6s Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 20.16 M Cbc Ps Lr Sft 6s Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 20.16 H Cbc Pto Lr Ps Set Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher 20.16 H Cbc Pto Lr Ps Set Hds Gb (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandhsd Lr Wf (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandchassis Lr (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandhsd Lr Sf (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandchassis Lr (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandhsd Lr Wf (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 15.16 Cabandhsd Lr Sf (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Lr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlandchassis Faceless (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandchassis Lr Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Hr Sf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandchassis Hr Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandfsd Lr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlandchassis Faceless (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Lr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandchassis Hr Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cab And Hsd Lrsf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlchassis Hds Faceless (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandfsd Lr Sf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandfsd Lr Sf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlandchassis Hds Face (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandfsd Lr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cab And Hsd Lrsf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlchassis Hds Faceless (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandchassis Lr Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Hr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Hr Sf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cowlandchassis Hds Face (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 Cabandhsd Hr Wf Hds (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Hcv 20.16 R Cwc Ps 6260w\/b Lft Eb Cr (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Front End With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Cab And Tipper Chassis With Pto (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Cab And Tipper Chassis With Wipro Twin Ram Kit (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Cabin And Chassis Pto And Wipro Tipping Kit (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Front End With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Cab And Tipper Chassis With Wipro Single Ram Kit (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Under Body Twin Ram With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Under Body Single Ram With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Under Body Twin Ram With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Fbt 8.5 Cu.m, Under Body Single Ram With Canopy (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Eicher Terra 16 Hdr Cbc Tr (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Milk Tanker Pro 5016 H (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Null Eicher 20.16 Tipper (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Pro 5016 M Refrigerated Van (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tanker Jumbo 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tanker Jumbo 15.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tanker Jumbo 15.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tanker Jumbo 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Terra 16 Xp (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tip Trailer 20.16 K Cbc Tip (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Pro 5016t (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Terra 16 Hdr (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Terra 16 E (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Terra 16xp E (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Pro 5016t E Rhd Bsiv 10 Ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher Jumbo 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 K Hsd (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 20.16 M Cbc Lft Indrl Bs3 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 M Slp Cbc 24ft. (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 J Slp Hsd 20ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 R Cwc. (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 Rhd M (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc. (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Hsd (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc Rhd 32ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 H Cwc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Hsd Rhd Bsiv 20ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Cbc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher Jumbo 15.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Cwc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher Jumbo 15.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc 32ft. (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 M Cbc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Sleeper Cab & Hsd (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 J Slp Cbc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 H Cbc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16. (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 M Cnt Rhd Bsiv 24 Ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 H Hsd Bsiv 18 Ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 R Cwc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 H Cwc Container (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 20.16 Chasis Only (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc Rhd (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher Jumbo 20.16 (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 K Cab And Chassis (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 M Slp Cbc 24ft (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc (16200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 H Cbc (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "1617 R Refrigerator Van (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Tipper 1623c 10.5 Cum Box Tipper (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Tipper 1623c (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1623c 4x2 Cbc (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R 4x2 Hsd (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1214 R Gvw 16200 (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R. (16200 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Water Tanker 1617 R 4x2 (16200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Swaraj Truck Wt49eshd (16200 GVW)"
 },
 {
  "Company": "Swaraj Mazda",
  "MakeModel": "Swaraj Truck Wt49eshd (16200 GVW)"
 },
 {
  "Company": "Force",
  "MakeModel": "Tippers Cla 16.220 4x2 (16200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 Gvw 16500 (16500 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R 4x2 Gvw 16800 (16800 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Hdlb Gvw 18000 (18000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Gvw 18000 (18000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Gvw 18000 (18000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6250mm Gvw 18000 (18000 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 K Hsd Gvw 18000 (18000 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Hsd 19 Ft Gvw 18020 (18020 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 Hsd Gvw 18137 (18137 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 Haulage 4300mm Gvw 18200 (18200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/1 Haulage 4700mm Gvw 18200 (18200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Cbc Gvw 18300 (18300 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1918 4x2 Gvw 18336 (18336 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Lpt\/1109\/36\/hd\/ex\/eii Lpt\/1109\/36\/hd\/ex\/eii (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Cr Bsiv Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Cowl Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Cr Bsiv Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Gvw 18500. (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Tc Gvw 18500. (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Bsiv Cowl 10x2 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Ultra 1518 Hdlb Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1618 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Sk 1613 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper 1612 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1618 10cum Box Tipper Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Se 1616 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Se 1613 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1616 Il Refrigerator Van (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "1618 Il Refrigerator Van Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Milk Tanker 1616 Il Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1616 Xl Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1613 H Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Truck 1616 Il Gvw 18500. (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Truck 1613 H Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Truck 1618\/4 4x2 Haulage 6250mm Bsiv Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 Gvw 18500. (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Il Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Ecomet 1214 19ft Hsd Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 4x2 Haulage 4330mm Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1616 Xl Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks Al 1616 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1612 Il Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6250mm Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6600mm Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/1 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Pro 5016t Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Tipper Terra 16 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 M Cnt Rhd Bsiv 24 Ft Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc 32 Ft Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks 15.16 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 Gvw 18500. (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 J Slp Hsd 20ft Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 M Cbc Rhd Bsiv 24 Ft Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3015 J Slp Cbc Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R 4x2 Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Bharat Benz",
  "MakeModel": "Trucks 1617 R Gvw 18500 (18500 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1615 10cum Box Tipper Gvw 18550 (18550 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6600mm Gvw 18550 (18550 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1613 Gvw 19000 (19000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1615 Cr Bsiv Gvw 19000 (19000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1918 (19000 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tata Trucks Lpt 1918 (19000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Tipper 1616 Xl Gvw 19000 (19000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6600mm Gvw 19000 (19000 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 3016 J Slp Hsd Gvw 19000 (19000 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/4 4x2 Haulage 6250mm Bsiv Gvw 19200 (19200 GVW)"
 },
 {
  "Company": "Ashok Leyland",
  "MakeModel": "Trucks 1618\/1 4700mm Gvw 19200 (19200 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Pro 5016 R Cwc Gvw 19200 (19200 GVW)"
 },
 {
  "Company": "Tata Motors",
  "MakeModel": "Tipper Lpk 1618 10cum Box Tipper Gvw 19500 (19500 GVW)"
 },
 {
  "Company": "Eicher Motors",
  "MakeModel": "Trucks Eicher 20.16 K Hsd Gvw 11990 (19990 GVW)"
 }
]


module.exports = {
    HCV2
  };